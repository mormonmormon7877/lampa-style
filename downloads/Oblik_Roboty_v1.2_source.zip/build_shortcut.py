from pathlib import Path
import base64,hashlib,zipfile
root=Path(__file__).parent
icon=(root/'Oblik_Roboty_1_2.ico').read_bytes()
payload=base64.b64encode(icon).decode()
lines=['@echo off','setlocal EnableExtensions DisableDelayedExpansion','chcp 65001 >nul','title Oblik roboty - desktop shortcut','set "APPDIR=%LOCALAPPDATA%\\OblikRoboty"','if not exist "%APPDIR%\\Oblik_Roboty.html" (echo Oblik roboty is not installed. Install the application first. & pause & exit /b 1)','set "BROWSER=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"','if not exist "%BROWSER%" (echo Chrome or Edge not found. & pause & exit /b 1)','set "ICONB64=%TEMP%\\oblik_shortcut_%RANDOM%_%RANDOM%.b64"','set "ICON_SHA256='+hashlib.sha256(icon).hexdigest()+'"']
for i in range(0,len(payload),120):lines.append(('>' if i==0 else '>>')+' "%ICONB64%" echo '+payload[i:i+120])
ps="$ErrorActionPreference='Stop'; $stage=Join-Path $env:APPDIR 'Oblik_Roboty_1_2.ico.new'; try { [IO.File]::WriteAllBytes($stage,[Convert]::FromBase64String([IO.File]::ReadAllText($env:ICONB64))); if ((Get-FileHash -LiteralPath $stage -Algorithm SHA256).Hash -ne $env:ICON_SHA256) { throw 'Icon checksum mismatch' }; $icon=Join-Path $env:APPDIR 'Oblik_Roboty_1_2.ico'; Move-Item -LiteralPath $stage -Destination $icon -Force; $sh=New-Object -ComObject WScript.Shell; $link=Join-Path ($sh.SpecialFolders('Desktop')) 'Облік роботи.lnk'; $s=$sh.CreateShortcut($link); if (-not $s.TargetPath -or -not (Test-Path -LiteralPath $s.TargetPath)) { $s.TargetPath=$env:BROWSER; $uri=([Uri](Join-Path $env:APPDIR 'Oblik_Roboty.html')).AbsoluteUri; $s.Arguments='--app='+[char]34+$uri+[char]34; $s.WorkingDirectory=$env:APPDIR }; $s.IconLocation=$icon+',0'; $s.Description='Облік виконаної роботи'; $s.Save(); Write-Host 'Desktop shortcut updated. Press F5 on the desktop if needed.' } catch { Write-Host ('ERROR: '+($_ | Out-String)); exit 1 } finally { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force -ErrorAction SilentlyContinue } }"
lines+=['powershell.exe -NoLogo -NoProfile -Command "'+ps+'"','set "RESULT=%ERRORLEVEL%"','del /q "%ICONB64%" >nul 2>&1','if not "%RESULT%"=="0" (echo Shortcut update failed. See the error above. & pause & exit /b 1)','echo Done. You can close this window.','pause','endlocal']
assert max(map(len,lines))<8191
(root/'SOZDAT_YARLYK_OBLIK_ROBOTY.cmd').write_bytes(('\r\n'.join(lines)+'\r\n').encode('utf-8'))
(root/'README_YARLYK.txt').write_text('''Ярлык «Облік роботи» для Windows 11
1. Распакуйте ZIP через «Извлечь всё».
2. Запустите SOZDAT_YARLYK_OBLIK_ROBOTY.cmd.
3. На рабочем столе появится ярлык с синей папкой, документом и зелёной галочкой.
Если значок не обновился сразу, нажмите F5 на рабочем столе.
Приложение должно быть установлено прежним установщиком в %LOCALAPPDATA%\\OblikRoboty.
Утилита сохраняет ICO в папке приложения и обновляет ярлык рабочего стола.
HTML-программа, документы, индекс, ручные исправления и даты не изменяются.
Если существующий ярлык настроен на свой браузер, этот выбор сохраняется.
Права администратора не требуются. Само создание ярлыка на Windows здесь не запускалось.
''',encoding='utf-8-sig')
with zipfile.ZipFile(root/'Yarlyk_Oblik_Roboty.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['SOZDAT_YARLYK_OBLIK_ROBOTY.cmd','README_YARLYK.txt']:z.write(root/name,name)
print('Built icon-only desktop shortcut updater')
