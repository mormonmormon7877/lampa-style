package main

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

type Event struct {
	At      string `json:"at"`
	Action  string `json:"action"`
	Message string `json:"message"`
}

func (s *Store) logEvent(action, message string) {
	s.logMu.Lock()
	defer s.logMu.Unlock()
	event := Event{time.Now().Format(time.RFC3339), action, message}
	s.events = append(s.events, event)
	if len(s.events) > 50 {
		s.events = s.events[len(s.events)-50:]
	}
	path := filepath.Join(filepath.Dir(s.path), "diagnostics.log")
	if info, err := os.Stat(path); err == nil && info.Size() > 512*1024 {
		_ = os.Remove(path + ".previous")
		_ = os.Rename(path, path+".previous")
	}
	if f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600); err == nil {
		fmt.Fprintf(f, "%s\t%s\t%s\n", event.At, event.Action, event.Message)
		f.Close()
	}
}
func (s *Store) problem(w http.ResponseWriter, action string, err error) {
	s.logEvent(action, err.Error())
	fail(w, err)
}
