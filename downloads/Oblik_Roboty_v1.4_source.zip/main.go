package main

import (
	"context"
	"crypto/rand"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"time"
)

//go:embed app.html
var page string

//go:embed Oblik_Roboty.ico
var icon []byte

const address = "127.0.0.1:47832"
const origin = "http://" + address
const version = "1.4"

func respond(w http.ResponseWriter, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(value)
}
func fail(w http.ResponseWriter, err error) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(400)
	respond(w, map[string]string{"error": err.Error()})
}
func decode(w http.ResponseWriter, r *http.Request, value any) error {
	return json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<20)).Decode(value)
}
func (s *Store) handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		if r.Host != address {
			http.Error(w, "Invalid host", 403)
			return
		}
		if r.Method != "GET" && r.Header.Get("Origin") != origin {
			http.Error(w, "Invalid origin", 403)
			return
		}
		if r.URL.Path == "/" {
			if r.Method != "GET" {
				http.Error(w, "Method not allowed", 405)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			fmt.Fprint(w, page)
			return
		}
		if r.URL.Path == "/Oblik_Roboty_1_2.ico" {
			w.Header().Set("Content-Type", "image/x-icon")
			w.Write(icon)
			return
		}
		if r.URL.Path == "/health" {
			w.Header().Set("X-Oblik-App", version)
			return
		}
		if r.URL.Path == "/api/index" && r.Method == "GET" {
			s.mu.Lock()
			defer s.mu.Unlock()
			respond(w, s.disk.Index)
			return
		}
		if r.URL.Path == "/api/diagnostics" && r.Method == "GET" {
			s.mu.Lock()
			defer s.mu.Unlock()
			s.logMu.Lock()
			defer s.logMu.Unlock()
			w.Header().Set("Content-Disposition", `attachment; filename="Oblik_diagnostics.json"`)
			logTail, _ := os.ReadFile(filepath.Join(filepath.Dir(s.path), "diagnostics.log"))
			if len(logTail) > 65536 {
				logTail = logTail[len(logTail)-65536:]
			}
			respond(w, map[string]any{"version": version, "os": runtime.GOOS, "sources": s.disk.Index.Sources, "rootPaths": s.disk.Roots, "recordCount": len(s.disk.Index.Items), "events": s.events, "logTail": string(logTail)})
			return
		}
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		if r.URL.Path == "/api/folder" {
			var input struct {
				Path   string `json:"path"`
				Source string `json:"source"`
			}
			if err := decode(w, r, &input); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			root := strings.TrimSpace(input.Path)
			var err error
			if root == "" {
				root, err = s.pick()
			}
			if err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			if root == "" {
				respond(w, map[string]bool{"cancelled": true})
				return
			}
			s.mu.Lock()
			defer s.mu.Unlock()
			root, err = canonicalRoot(root)
			if err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			report, err := s.scanDetailed(root)
			if err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			tokenBytes := make([]byte, 24)
			if _, err = rand.Read(tokenBytes); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			for key, selection := range s.pending {
				if time.Since(selection.Created) > 10*time.Minute {
					delete(s.pending, key)
				}
			}
			token := hex.EncodeToString(tokenBytes)
			s.pending[token] = Selection{root, time.Now()}
			s.logEvent("folder", fmt.Sprintf("%s: documents=%d skipped=%d complete=%v", root, len(report.Files), report.Skipped, report.Complete))
			respond(w, map[string]any{"token": token, "files": report.Files, "root": rootName(root), "source": s.suggestSource(root, input.Source), "warnings": report.Warnings, "complete": report.Complete, "skipped": report.Skipped, "total": report.Total})
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		switch r.URL.Path {
		case "/api/index":
			var index Index
			if err := decode(w, r, &index); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			if err := s.update(index); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			respond(w, map[string]bool{"ok": true})
		case "/api/bind":
			var value struct {
				Source string `json:"source"`
				Token  string `json:"token"`
			}
			if err := decode(w, r, &value); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			selection, ok := s.pending[value.Token]
			if !ok || value.Source == "" || time.Since(selection.Created) > 10*time.Minute {
				s.problem(w, r.URL.Path, errors.New("Вибір папки застарів. Виберіть її повторно"))
				return
			}
			if old := s.disk.Roots[value.Source]; old != "" && !sameRoot(old, selection.Root) {
				s.problem(w, r.URL.Path, errors.New("Для цього джерела вже вибрана інша фізична папка. Створіть нове джерело для іншої папки"))
				return
			}
			roots := map[string]string{}
			for key, root := range s.disk.Roots {
				roots[key] = root
			}
			roots[value.Source] = selection.Root
			next := Disk{Index: s.disk.Index, Roots: roots}
			if err := atomicSave(s.path, next); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			s.disk = next
			delete(s.pending, value.Token)
			respond(w, map[string]bool{"ok": true})
		case "/api/shortcut":
			path, err := platformShortcut()
			if err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			s.logEvent("shortcut", "Desktop shortcut created")
			respond(w, map[string]string{"path": path})
		case "/api/open":
			var value struct {
				Source string `json:"source"`
				Path   string `json:"path"`
			}
			if err := decode(w, r, &value); err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			path, err := s.resolve(value.Source, value.Path)
			if err != nil {
				s.problem(w, r.URL.Path, err)
				return
			}
			if err = s.open(path); err != nil {
				s.problem(w, r.URL.Path, fmt.Errorf("Windows не відкрила файл. Перевірте, чи встановлена програма для цього формату: %w", err))
				return
			}
			s.logEvent("open", "Request passed to Windows for source "+value.Source)
			respond(w, map[string]bool{"ok": true})
		default:
			http.NotFound(w, r)
		}
	})
}
func openBrowser() error {
	if runtime.GOOS == "windows" {
		paths := []string{filepath.Join(os.Getenv("ProgramFiles"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("ProgramFiles(x86)"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("ProgramFiles(x86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("ProgramFiles"), "Microsoft", "Edge", "Application", "msedge.exe")}
		for _, path := range paths {
			if info, err := os.Stat(path); err == nil && !info.IsDir() {
				return exec.Command(path, "--app="+origin+"/").Start()
			}
		}
		return errors.New("Chrome or Edge not found")
	}
	return nil
}
func report(err error) {
	fmt.Fprintln(os.Stderr, err)
	if runtime.GOOS == "windows" {
		syscallMessage(err.Error())
	}
}
func main() {
	dir := os.Getenv("OBLIK_CONFIG_DIR")
	if dir == "" {
		base, err := os.UserConfigDir()
		if err != nil {
			report(err)
			return
		}
		dir = filepath.Join(base, "OblikRobotyNative")
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		report(err)
		return
	}
	s := &Store{path: filepath.Join(dir, "index.json"), disk: Disk{Index: empty(), Roots: map[string]string{}}, pending: map[string]Selection{}, open: openDocument, pick: selectFolder}
	if raw, err := os.ReadFile(s.path); err == nil {
		var stored Disk
		if err = json.Unmarshal(raw, &stored); err != nil {
			report(fmt.Errorf("Index is damaged; it has not been overwritten: %w", err))
			return
		}
		if err = validate(stored.Index); err != nil {
			report(err)
			return
		}
		if stored.Roots == nil {
			stored.Roots = map[string]string{}
		}
		s.disk = stored
	} else if !os.IsNotExist(err) {
		report(err)
		return
	}
	listener, err := net.Listen("tcp4", address)
	if err != nil {
		client := &http.Client{Timeout: 2 * time.Second}
		r, e := client.Get(origin + "/health")
		if e == nil {
			r.Body.Close()
			if r.Header.Get("X-Oblik-App") == version {
				if e = openBrowser(); e != nil {
					report(e)
				}
				return
			}
			if strings.HasPrefix(r.Header.Get("X-Oblik-App"), "1.") {
				report(errors.New("Працює попередня версія. Натисніть у ній «Завершити програму» або перезавантажте Windows, потім запустіть 1.4."))
				return
			}
		}
		report(err)
		return
	}
	var seen atomic.Int64
	seen.Store(time.Now().Unix())
	base := s.handler()
	server := &http.Server{ReadHeaderTimeout: 5 * time.Second}
	shutdownDone := make(chan struct{})
	var shuttingDown atomic.Bool
	shutdown := func() {
		if shuttingDown.CompareAndSwap(false, true) {
			go func() {
				ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
				defer cancel()
				_ = server.Shutdown(ctx)
				close(shutdownDone)
			}()
		}
	}
	server.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != address {
			http.Error(w, "Invalid host", 403)
			return
		}
		if r.URL.Path == "/alive" || r.URL.Path == "/quit" {
			if r.Method != "POST" || r.Header.Get("Origin") != origin {
				http.Error(w, "Invalid origin", 403)
				return
			}
			seen.Store(time.Now().Unix())
			w.WriteHeader(204)
			if r.URL.Path == "/quit" {
				shutdown()
			}
			return
		}
		seen.Store(time.Now().Unix())
		base.ServeHTTP(w, r)
	})
	go func() {
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for range ticker.C {
			if time.Now().Unix()-seen.Load() > 600 {
				shutdown()
				return
			}
		}
	}()
	if os.Getenv("OBLIK_NO_BROWSER") != "1" {
		if err = openBrowser(); err != nil {
			report(err)
			listener.Close()
			return
		}
	}
	if err = server.Serve(listener); err != nil && err != http.ErrServerClosed {
		report(err)
	}
	if shuttingDown.Load() {
		<-shutdownDone
	}
}
