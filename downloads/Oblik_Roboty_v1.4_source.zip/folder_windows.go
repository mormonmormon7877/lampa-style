package main

import (
	"fmt"
	"runtime"
	"syscall"
	"unsafe"
)

type browseInfo struct {
	Owner    uintptr
	Root     uintptr
	Display  *uint16
	Title    *uint16
	Flags    uint32
	Callback uintptr
	Param    uintptr
	Image    int32
}

func selectFolder() (string, error) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	ole := syscall.NewLazyDLL("ole32.dll")
	r, _, _ := ole.NewProc("OleInitialize").Call(0)
	if int32(r) < 0 {
		return "", syscall.Errno(r)
	}
	defer ole.NewProc("OleUninitialize").Call()
	title, _ := syscall.UTF16PtrFromString("Оберіть папку з документами (наприклад, на диску D:). Файли не копіюються.")
	display := make([]uint16, 32768)
	info := browseInfo{Display: &display[0], Title: title, Flags: 0x41}
	shell := syscall.NewLazyDLL("shell32.dll")
	pidl, _, _ := shell.NewProc("SHBrowseForFolderW").Call(uintptr(unsafe.Pointer(&info)))
	if pidl == 0 {
		return "", nil
	}
	defer ole.NewProc("CoTaskMemFree").Call(pidl)
	buf := make([]uint16, 32768)
	ok, _, err := shell.NewProc("SHGetPathFromIDListW").Call(pidl, uintptr(unsafe.Pointer(&buf[0])))
	if ok == 0 {
		return "", err
	}
	return syscall.UTF16ToString(buf), nil
}
func openDocument(path string) error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	ole := syscall.NewLazyDLL("ole32.dll")
	status, _, _ := ole.NewProc("OleInitialize").Call(0)
	if int32(status) < 0 {
		return fmt.Errorf("OleInitialize failed: 0x%x", status)
	}
	defer ole.NewProc("OleUninitialize").Call()
	verb, _ := syscall.UTF16PtrFromString("open")
	p, _ := syscall.UTF16PtrFromString(path)
	r, _, err := syscall.NewLazyDLL("shell32.dll").NewProc("ShellExecuteW").Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(p)), 0, 0, 1)
	if r <= 32 {
		labels := map[uintptr]string{2: "Файл не знайдено", 3: "Папку не знайдено", 5: "Windows відмовила у доступі", 26: "Документ зайнятий іншою програмою", 27: "Некоректна прив’язка типу файла", 28: "Програма не відповіла вчасно", 29: "Не вдалося зв’язатися з програмою", 30: "Програма зайнята", 31: "Для цього формату не призначено програму. Виберіть Word, PDF-переглядач або іншу потрібну програму у Windows", 32: "Потрібний компонент Windows недоступний"}
		if label := labels[r]; label != "" {
			return fmt.Errorf("%s (код %d)", label, r)
		}
		return fmt.Errorf("Windows не відкрила документ (код %d): %v", r, err)
	}
	return nil
}
