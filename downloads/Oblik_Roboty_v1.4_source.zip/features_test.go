package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestDirectQuotedPathAndConsentImages(t *testing.T) {
	s, _, _ := testStore(t)
	root := filepath.Join(t.TempDir(), "Письмова Згода")
	os.Mkdir(root, 0700)
	os.WriteFile(filepath.Join(root, "скан.jpg"), []byte("synthetic image"), 0600)
	os.WriteFile(filepath.Join(root, "скан.png"), []byte("synthetic png"), 0600)
	os.WriteFile(filepath.Join(root, "ignore.exe"), []byte("ignored"), 0600)
	body, _ := json.Marshal(map[string]string{"path": "\"" + root + "\""})
	w := call(s, "POST", "/api/folder", origin, string(body))
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	var result struct {
		Token    string     `json:"token"`
		Files    []ScanFile `json:"files"`
		Skipped  int        `json:"skipped"`
		Complete bool       `json:"complete"`
	}
	json.Unmarshal(w.Body.Bytes(), &result)
	if len(result.Files) != 2 || result.Skipped != 1 || !result.Complete {
		t.Fatal(w.Body.String())
	}
	bind, _ := json.Marshal(map[string]string{"source": "consent-source", "token": result.Token})
	w = call(s, "POST", "/api/bind", origin, string(bind))
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	index := Index{Version: 1, Sources: []Source{{ID: "consent-source", Label: "Письмова Згода", Root: "Письмова Згода"}}, Items: []Item{}}
	for _, f := range result.Files {
		index.Items = append(index.Items, Item{Source: "consent-source", Path: f.Path, Name: f.Name, Size: f.Size, Modified: f.Modified, Type: "consent", Reason: "folder"})
	}
	if err := s.update(index); err != nil {
		t.Fatal(err)
	}
	body, _ = json.Marshal(map[string]string{"path": root})
	w = call(s, "POST", "/api/folder", origin, string(body))
	var again struct {
		Source string `json:"source"`
	}
	json.Unmarshal(w.Body.Bytes(), &again)
	if again.Source != "consent-source" {
		t.Fatal("Existing physical folder not detected", w.Body.String())
	}
	opened := ""
	s.open = func(path string) error { opened = path; return nil }
	body, _ = json.Marshal(map[string]string{"source": "consent-source", "path": index.Items[0].Path})
	if w = call(s, "POST", "/api/open", origin, string(body)); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if !strings.HasPrefix(opened, root+string(filepath.Separator)) {
		t.Fatal(opened)
	}
}
func TestBadDirectPathDoesNotChangeIndex(t *testing.T) {
	s, _, file := testStore(t)
	for _, path := range []string{"relative", file, filepath.Join(t.TempDir(), "missing")} {
		body, _ := json.Marshal(map[string]string{"path": path})
		if w := call(s, "POST", "/api/folder", origin, string(body)); w.Code != 400 {
			t.Fatal("Invalid folder accepted", path, w.Body.String())
		}
	}
	if len(s.disk.Index.Sources) != 0 {
		t.Fatal("Failed scan changed index")
	}
	w := call(s, "GET", "/api/diagnostics", "", "")
	if w.Code != 200 || !strings.Contains(w.Body.String(), "1.4") {
		t.Fatal(w.Body.String())
	}
	raw, err := os.ReadFile(filepath.Join(filepath.Dir(s.path), "diagnostics.log"))
	if err != nil || !strings.Contains(string(raw), "/api/folder") {
		t.Fatal("Diagnostic log missing", err)
	}
}
func TestUnreadableBranchDoesNotPretendScanComplete(t *testing.T) {
	s, root, _ := testStore(t)
	hidden := filepath.Join(root, "restricted")
	os.Mkdir(hidden, 0700)
	os.WriteFile(filepath.Join(hidden, "hidden.docx"), []byte("test"), 0600)
	os.Chmod(hidden, 0000)
	defer os.Chmod(hidden, 0700)
	if _, err := os.ReadDir(hidden); err == nil {
		t.Skip("Runner bypasses filesystem permissions")
	}
	report, err := s.scanDetailed(root)
	if err != nil {
		t.Fatal(err)
	}
	if report.Complete || len(report.Warnings) == 0 || len(report.Files) != 1 {
		t.Fatalf("Partial scan not reported: %+v", report)
	}
}
