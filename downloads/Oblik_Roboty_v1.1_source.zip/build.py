from pathlib import Path
import re,base64,hashlib,zipfile
root=Path(__file__).parent
html=(root/'Oblik_Roboty.original.html').read_text()
html=re.sub(r'<script>.*?</script>',lambda m:'<script>\n'+(root/'logic.js').read_text()+'\n</script>',html,flags=re.S)
html=html.replace('v1.0','v1.1').replace('<title>Облік роботи — індексатор</title>','<title>Облік роботи 1.1 — індексатор</title>')
html=html.replace('<div class="panel"><div class="flex">','<div class="panel" id="controls"><div class="flex">',1)
html=html.replace('<label for="folder" class="btn">','<label for="source">Джерело</label><select id="source"><option value="">＋ Нова папка / інший диск</option></select><label for="folder" class="btn">',1)
html=html.replace('<p class="hint">Обирай папку,','<p id="notice" class="hint" role="status" aria-live="polite"></p><p class="hint">Для іншого диска чи іншої папки виберіть «Нова папка / інший диск» і задайте окрему назву, наприклад «D: Архів». Для повторного сканування виберіть існуюче джерело. Браузер не показує повного системного шляху. Обирай папку,',1)
html=html.replace('<option value="modified">','<option value="completed">Дата виконання (вручну)</option><option value="modified" selected>',1)
html=html.replace('<option value="all">','<option value="all" selected>',1)
html=html.replace('<div class="stats">','<div class="panel"><button id="backup">Резервна копія індексу</button> <button id="restore" class="secondary">Відновити індекс</button><input id="restoreFile" type="file" accept=".json"><label><input type="checkbox" id="includeMissing"> Показувати файли, не знайдені під час останнього сканування</label><p class="hint">Зберігаються лише назви, ручні типи та дати — без копій документів. Резервна копія індексу не містить сканів. Рахуються файли: Word і PDF одного документа можуть бути двома записами.</p></div><div class="stats">',1)
html=html.replace('<th>Дата файлу</th><th>Розташування</th>','<th>Дата виконання</th><th>Дата звіту</th><th>Розташування</th><th>Доступ</th>')
html=html.replace('colspan="4"','colspan="6"')
html=html.replace('Після закриття вкладки індекс не зберігається — для безпеки повторно вибери папку.','Індекс і ручні виправлення зберігаються в цьому браузері. Після перезапуску доступ до файлів потрібно поновити повторним вибором папки. Для перенесення індексу використовуйте резервну копію. Якщо файл зник із папки, запис зберігається як недоступний та виключається зі звичайного підрахунку.')
html=html.replace('<script>','<dialog id="dialog"><form id="form"><h2 id="prompt"></h2><input id="answer" required><button type="submit">Зберегти</button> <button type="button" id="cancel" class="secondary">Скасувати</button></form></dialog><script>',1)
html=html.replace('</style>','dialog{border:1px solid #ccd5e0;border-radius:12px;max-width:500px;width:90%}dialog::backdrop{background:#0006}dialog input{width:100%;margin:12px 0}small{display:block;margin-top:5px;color:#63718a}td input[type=date]{width:150px}#notice{white-space:pre-wrap}</style>',1)
raw=html.encode();(root/'Oblik_Roboty.html').write_bytes(raw)
encoded=base64.b64encode(raw).decode();checksum=hashlib.sha256(raw).hexdigest()
lines=['@echo off','setlocal EnableExtensions DisableDelayedExpansion','chcp 65001 >nul','title Oblik roboty 1.1 - install','set "APPDIR=%LOCALAPPDATA%\\OblikRoboty"','if not exist "%APPDIR%" mkdir "%APPDIR%"','if not exist "%APPDIR%" (echo Cannot create application folder. & pause & exit /b 1)','set "BROWSER=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"','if not exist "%BROWSER%" (echo Chrome or Edge was not found. & pause & exit /b 1)','set "B64=%TEMP%\\oblik_install_%RANDOM%_%RANDOM%.b64"',f'set "EXPECTED_SHA256={checksum}"']
for i in range(0,len(encoded),120):lines.append(('>' if i==0 else '>>')+' "%B64%" echo '+encoded[i:i+120])
ps="$ErrorActionPreference='Stop'; $stage=Join-Path $env:APPDIR 'Oblik_Roboty.html.new'; try { $bytes=[Convert]::FromBase64String([IO.File]::ReadAllText($env:B64)); [IO.File]::WriteAllBytes($stage,$bytes); if ((Get-FileHash -LiteralPath $stage -Algorithm SHA256).Hash -ne $env:EXPECTED_SHA256) { throw 'Installer checksum mismatch' }; Move-Item -LiteralPath $stage -Destination (Join-Path $env:APPDIR 'Oblik_Roboty.html') -Force; $sh=New-Object -ComObject WScript.Shell; $link=Join-Path ($sh.SpecialFolders('Desktop')) 'Облік роботи.lnk'; $s=$sh.CreateShortcut($link); $s.TargetPath=$env:BROWSER; $uri=([Uri](Join-Path $env:APPDIR 'Oblik_Roboty.html')).AbsoluteUri; $s.Arguments='--app='+[char]34+$uri+[char]34; $s.WorkingDirectory=$env:APPDIR; $s.Description='Облік виконаної роботи 1.1'; $s.Save(); $sh.Run([char]34+$link+[char]34,1,$false) | Out-Null } catch { Write-Host ('ERROR: '+($_ | Out-String)); exit 1 } finally { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force -ErrorAction SilentlyContinue } }"
lines+=['powershell.exe -NoLogo -NoProfile -Command "'+ps+'"','set "RESULT=%ERRORLEVEL%"','del /q "%B64%" >nul 2>&1','if not "%RESULT%"=="0" (echo Installation failed. See the error above. & pause & exit /b 1)','echo Installed. Use the desktop shortcut next time.','pause','endlocal']
assert max(map(len,lines))<8191
(root/'USTANOVIT_OBLIK_ROBOTY_1.1.cmd').write_bytes(('\r\n'.join(lines)+'\r\n').encode('utf-8'))
(root/'README.txt').write_text('''Облік роботи 1.1 — Windows 11 / Chrome / Edge
Распакуйте ZIP. Запустите USTANOVIT_OBLIK_ROBOTY_1.1.cmd.
Ярлык «Облік роботи» появится на рабочем столе.
Существующий HTML установщик обновляет; сохранённый индекс не удаляет.
В версии 1.0 индекс был временным: закрытый индекс оттуда восстановить невозможно.

Для каждой отдельной физической папки создайте отдельное «Джерело».
Например: «D: Архів» и «E: Архів». Браузер не раскрывает абсолютный путь.
Для повторного сканирования сначала выберите уже созданное джерело.
Ручные типы и даты выполнения сохраняются. Исчезнувшие файлы отмечаются и исключаются из обычного подсчёта.
Документы не копируются. На C: хранится небольшой HTML и метаданные браузера, без сканов.
Отчёт считает файлы, а не уникальные выполненные работы. Word и PDF одного документа считаются отдельно.
Для достоверного отчёта заполните «Дата виконання» и выберите её в «За якою датою рахувати».
Сохраните резервную копию индекса перед очисткой браузера. Она не содержит документы.
Содержимое Word/PDF не распознаётся; тип определяется по названиям, спорные записи отмечаются.
PDF можно просмотреть после выбора папки. Word открывайте в исходной папке.
Новые функции проверены в Chromium. Сам CMD и ярлык на Windows здесь не запускались.
''',encoding='utf-8-sig')
with zipfile.ZipFile(root/'Oblik_Roboty_Windows11_v1.1.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['USTANOVIT_OBLIK_ROBOTY_1.1.cmd','README.txt']:z.write(root/name,name)
print('Built HTML, self-contained CMD, Windows ZIP. HTML SHA256:',checksum)
