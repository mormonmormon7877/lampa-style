package main

import (
	"encoding/json"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func testStore(t *testing.T) (*Store, string, string) {
	t.Helper()
	base := t.TempDir()
	root := filepath.Join(base, "Архів")
	os.MkdirAll(root, 0700)
	file := filepath.Join(root, "Рекомендаційний лист.docx")
	os.WriteFile(file, []byte("original document bytes"), 0600)
	s := &Store{path: filepath.Join(t.TempDir(), "index.json"), disk: Disk{Index: empty(), Roots: map[string]string{}}, pending: map[string]Selection{}, pick: func() (string, error) { return root, nil }, open: func(path string) error { return nil }}
	return s, root, file
}
func call(s *Store, method, path, originHeader, body string) *httptest.ResponseRecorder {
	r := httptest.NewRequest(method, origin+path, strings.NewReader(body))
	if originHeader != "" {
		r.Header.Set("Origin", originHeader)
	}
	w := httptest.NewRecorder()
	s.handler().ServeHTTP(w, r)
	return w
}
func TestScanBindOpenOriginalAndRestart(t *testing.T) {
	s, root, file := testStore(t)
	w := call(s, "POST", "/api/folder", origin, "{}")
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	var selection struct {
		Token string     `json:"token"`
		Files []ScanFile `json:"files"`
	}
	json.Unmarshal(w.Body.Bytes(), &selection)
	if len(selection.Files) != 1 || selection.Files[0].Path != "Архів/Рекомендаційний лист.docx" {
		t.Fatal(w.Body.String())
	}
	bind, _ := json.Marshal(map[string]string{"source": "D", "token": selection.Token})
	if w = call(s, "POST", "/api/bind", origin, string(bind)); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	index := Index{Version: 1, Sources: []Source{{"D", "D: Архів", "Архів"}}, Items: []Item{{Source: "D", Path: selection.Files[0].Path, Name: selection.Files[0].Name, Modified: selection.Files[0].Modified, Size: selection.Files[0].Size, Type: "rec", Reason: "test", Completed: "2026-10-10"}}}
	body, _ := json.Marshal(index)
	if w = call(s, "POST", "/api/index", origin, string(body)); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	opened := ""
	s.open = func(path string) error { opened = path; return nil }
	body, _ = json.Marshal(map[string]string{"source": "D", "path": selection.Files[0].Path})
	if w = call(s, "POST", "/api/open", origin, string(body)); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if opened != file {
		t.Fatalf("opened %s instead of %s", opened, file)
	}
	raw, _ := os.ReadFile(s.path)
	if strings.Contains(string(raw), "original document bytes") {
		t.Fatal("document was copied into metadata")
	}
	var saved Disk
	if err := json.Unmarshal(raw, &saved); err != nil {
		t.Fatal(err)
	}
	restarted := &Store{disk: saved}
	resolved, err := restarted.resolve("D", index.Items[0].Path)
	if err != nil || resolved != file {
		t.Fatal("restart lost binding", err)
	}
	if saved.Roots["D"] != root {
		t.Fatal(saved.Roots)
	}
	original, _ := os.ReadFile(file)
	if string(original) != "original document bytes" {
		t.Fatal("original changed")
	}
}
func TestOpeningRejectsMissingUnregisteredAndEscapes(t *testing.T) {
	s, root, file := testStore(t)
	s.disk = Disk{Index: Index{Version: 1, Sources: []Source{{"D", "D", "Архів"}}, Items: []Item{{Source: "D", Path: "Архів/Рекомендаційний лист.docx", Name: "Рекомендаційний лист.docx", Type: "rec"}}}, Roots: map[string]string{"D": root}}
	if _, err := s.resolve("D", "Архів/../outside.docx"); err == nil {
		t.Fatal("traversal accepted")
	}
	if _, err := s.resolve("D", "Архів/unregistered.docx"); err == nil {
		t.Fatal("unregistered file accepted")
	}
	os.Remove(file)
	if _, err := s.resolve("D", s.disk.Index.Items[0].Path); err == nil {
		t.Fatal("missing file accepted")
	}
	outside := filepath.Join(t.TempDir(), "outside.docx")
	os.WriteFile(outside, []byte("outside"), 0600)
	if err := os.Symlink(outside, file); err == nil {
		if _, err = s.resolve("D", s.disk.Index.Items[0].Path); err == nil {
			t.Fatal("symlink outside source accepted")
		}
	}
	before := len(s.disk.Index.Items)
	if w := call(s, "POST", "/api/index", origin, `{"version":1,"sources":[],"items":[{"name":"bad.exe"}]}`); w.Code != 400 || len(s.disk.Index.Items) != before {
		t.Fatal("invalid index changed state")
	}
	if w := call(s, "POST", "/api/open", "https://evil.test", `{}`); w.Code != 403 {
		t.Fatal("cross origin allowed")
	}
}
func TestCannotRebindSourceToDifferentPhysicalRoot(t *testing.T) {
	s, root, _ := testStore(t)
	s.disk.Roots["D"] = root
	s.pending["new"] = Selection{Root: t.TempDir(), Created: time.Now()}
	w := call(s, "POST", "/api/bind", origin, `{"source":"D","token":"new"}`)
	if w.Code != 400 || s.disk.Roots["D"] != root {
		t.Fatal("existing physical source overwritten")
	}
}
