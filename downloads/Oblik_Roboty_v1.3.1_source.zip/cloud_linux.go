package main

func platformCloudFile(path string) bool { return false }
