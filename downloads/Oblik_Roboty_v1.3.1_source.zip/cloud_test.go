package main

import "testing"

func TestCloudTagsExcludeLinksAndOtherReparsePoints(t *testing.T) {
	for variant := uint32(0); variant < 16; variant++ {
		if !isCloudTag(0x9000001A | variant<<12) {
			t.Fatalf("Cloud variant %d rejected", variant)
		}
	}
	if !isCloudTag(0x80000021) {
		t.Fatal("OneDrive tag rejected")
	}
	for _, tag := range []uint32{0, 0xA000000C, 0xA0000003, 0x80000023, 0x9000001B} {
		if isCloudTag(tag) {
			t.Fatalf("Non-cloud reparse tag %x accepted", tag)
		}
	}
}
