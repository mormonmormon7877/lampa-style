package main

import "syscall"

func platformCloudFile(path string) bool {
	p, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return false
	}
	var data syscall.Win32finddata
	handle, err := syscall.FindFirstFile(p, &data)
	if err != nil {
		return false
	}
	defer syscall.FindClose(handle)
	return data.FileAttributes&syscall.FILE_ATTRIBUTE_DIRECTORY == 0 &&
		data.FileAttributes&syscall.FILE_ATTRIBUTE_REPARSE_POINT != 0 &&
		isCloudTag(data.Reserved0)
}
