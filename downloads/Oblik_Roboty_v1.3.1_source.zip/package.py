from pathlib import Path
import hashlib,zipfile
root=Path(__file__).parent
exe=root/'Oblik_Roboty.exe';ico=root/'Oblik_Roboty.ico'
lines=['@echo off','setlocal EnableExtensions DisableDelayedExpansion','chcp 65001 >nul','title Oblik roboty 1.3.1 - install','set "APPDIR=%LOCALAPPDATA%\\OblikRoboty"','if not exist "%~dp0Oblik_Roboty.exe" (echo Extract all ZIP files before running this installer. & pause & exit /b 1)','if not exist "%~dp0Oblik_Roboty.ico" (echo Icon file is missing. Extract the entire ZIP. & pause & exit /b 1)','if not exist "%APPDIR%" mkdir "%APPDIR%"','if not exist "%APPDIR%" (echo Cannot create application folder. & pause & exit /b 1)','copy /y "%~dp0Oblik_Roboty.exe" "%APPDIR%\\Oblik_Roboty.exe.new" >nul','if errorlevel 1 (echo Cannot copy application. & pause & exit /b 1)','copy /y "%~dp0Oblik_Roboty.ico" "%APPDIR%\\Oblik_Roboty_1_3.ico.new" >nul','if errorlevel 1 (echo Cannot copy icon. & pause & exit /b 1)','set "EXE_SHA256='+hashlib.sha256(exe.read_bytes()).hexdigest()+'"','set "ICO_SHA256='+hashlib.sha256(ico.read_bytes()).hexdigest()+'"','set "BROWSER=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"','if not exist "%BROWSER%" set "BROWSER=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"','if not exist "%BROWSER%" (echo Chrome or Edge not found. & pause & exit /b 1)']
ps="$ErrorActionPreference='Stop'; $exeStage=Join-Path $env:APPDIR 'Oblik_Roboty.exe.new'; $icoStage=Join-Path $env:APPDIR 'Oblik_Roboty_1_3.ico.new'; try { if ((Get-FileHash -LiteralPath $exeStage -Algorithm SHA256).Hash -ne $env:EXE_SHA256) { throw 'EXE checksum mismatch' }; if ((Get-FileHash -LiteralPath $icoStage -Algorithm SHA256).Hash -ne $env:ICO_SHA256) { throw 'ICO checksum mismatch' }; $target=Join-Path $env:APPDIR 'Oblik_Roboty.exe'; $icon=Join-Path $env:APPDIR 'Oblik_Roboty_1_3.ico'; Move-Item -LiteralPath $exeStage -Destination $target -Force; Move-Item -LiteralPath $icoStage -Destination $icon -Force; $sh=New-Object -ComObject WScript.Shell; $desktop=$sh.SpecialFolders('Desktop'); $link=Join-Path $desktop 'Облік роботи.lnk'; $s=$sh.CreateShortcut($link); $oldHtml=Join-Path $env:APPDIR 'Oblik_Roboty.html'; $oldLink=Join-Path $desktop 'Облік роботи (попередня).lnk'; if ((Test-Path -LiteralPath $oldHtml) -and -not (Test-Path -LiteralPath $oldLink)) { $legacy=$sh.CreateShortcut($oldLink); if (([IO.Path]::GetFileName($s.TargetPath) -in @('chrome.exe','msedge.exe')) -and (Test-Path -LiteralPath $s.TargetPath)) { $legacy.TargetPath=$s.TargetPath; $legacy.Arguments=$s.Arguments } else { $legacy.TargetPath=$env:BROWSER; $uri=([Uri]$oldHtml).AbsoluteUri; $legacy.Arguments='--app='+[char]34+$uri+[char]34 }; $legacy.WorkingDirectory=$env:APPDIR; $legacy.IconLocation=$icon+',0'; $legacy.Save() }; $s.TargetPath=$target; $s.Arguments=''; $s.WorkingDirectory=$env:APPDIR; $s.IconLocation=$icon+',0'; $s.Description='Облік роботи 1.3.1 - відкриття оригіналів'; $s.Save(); $sh.Run([char]34+$link+[char]34,1,$false) | Out-Null } catch { Write-Host ('ERROR: '+($_ | Out-String)); exit 1 } finally { foreach ($stage in @($exeStage,$icoStage)) { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force -ErrorAction SilentlyContinue } } }"
lines+=['powershell.exe -NoLogo -NoProfile -Command "'+ps+'"','if errorlevel 1 (echo Installation failed. Close the running native application before reinstalling. & pause & exit /b 1)','echo Installed. Use the Oblik roboty desktop shortcut.','pause','endlocal']
assert max(map(len,lines))<8191
(root/'USTANOVIT_OBLIK_ROBOTY_1.3.1.cmd').write_bytes(('\r\n'.join(lines)+'\r\n').encode('utf-8'))
(root/'README.txt').write_text('''Облік роботи 1.3.1 — Windows 11 x64 — открытие оригиналов

ИСПРАВЛЕНИЕ 1.3.1
Файлы OneDrive/облачной синхронизации больше не отбрасываются только из-за служебного типа Windows.
Поддержаны облачные метки Windows SDK; символические ссылки и выход за пределы источника по-прежнему блокируются.
Работа именно с вашим OneDrive и запуск Word на Windows здесь не проверены.

ПЕРЕД ОБНОВЛЕНИЕМ
В работающей версии нажмите «Завершити програму» или перезагрузите Windows перед установкой.
В прежней версии нажмите «Резервна копія індексу» и сохраните JSON.
Распакуйте новый ZIP через «Извлечь всё». Запустите USTANOVIT_OBLIK_ROBOTY_1.3.1.cmd.
Установщик обновляет ярлык «Облік роботи» и сохраняет красивый значок.
Python, Go и дополнительные компоненты устанавливать не нужно. Права администратора не требуются.
Не удаляйте файлы из ZIP до установки: EXE и ICO должны лежать рядом с CMD.

ПЕРЕНОС ИНДЕКСА
Нажмите «Відновити індекс» в новой программе и выберите JSON из старой версии.
Для каждого источника выберите его в «Джерело», затем «Обрати папку для індексації» и укажите прежнюю папку.
Ручные типы и даты выполнения сохраняются. Старый браузерный индекс автоматически не переносится.
Если копия не была сохранена, установщик оставляет «Облік роботи (попередня)» для открытия старой версии и экспорта копии.
Старые HTML, документы и браузерное хранилище не удаляются.

КАК ОТКРЫТЬ РЕКОМЕНДАТЕЛЬНЫЙ ЛИСТ
Найдите нужную строку и нажмите «Відкрити оригінал» справа.
DOC/DOCX открываются стандартной программой Windows (обычно Word), PDF — стандартным PDF-просмотрщиком.
Приложение передаёт исходный путь Windows и не скачивает/не копирует документ на C:.
Нужная программа для формата должна быть установлена. Перемещённые или удалённые документы не откроются — появится сообщение.
После подключения папки её не нужно выбирать при каждом запуске: путь сохраняется.

ГДЕ ДАННЫЕ
Индекс и пути сохраняются в %APPDATA%\\OblikRobotyNative\\index.json; .bak содержит предыдущую версию метаданных.
Там нет содержимого документов. Файлы остаются в исходных папках.
Резервная копия индекса также содержит только метаданные, без сканов.
В новой установке папки источников нужно подключить повторно после восстановления JSON.
Для другой физической папки создавайте новое джерело: повторная привязка существующего к другому пути блокируется.
Кнопка «Завершити програму» завершает локальный процесс. Работает только локально, на 127.0.0.1:47832.

Сборка Windows x64 выполнена. Проверены индекс, передача точного пути системному открывателю, отсутствие копирования,
сохранение связей после перезапуска, импорт прежнего индекса, отсутствующие файлы и блокировка выхода за пределы выбранной папки.
В интеграционном тесте системное открытие имитируется в Linux. Сам запуск Word и окно выбора папки Windows здесь не проверялись.
EXE не подписана цифровой подписью. Шифрование данных не реализовано.
''',encoding='utf-8-sig')
with zipfile.ZipFile(root/'Oblik_Roboty_Windows11_v1.3.1.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['USTANOVIT_OBLIK_ROBOTY_1.3.1.cmd','Oblik_Roboty.exe','Oblik_Roboty.ico','README.txt']:z.write(root/name,name)
print('Packaged native Windows application, installer, icon and instructions')
