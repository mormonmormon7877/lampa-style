package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type Source struct {
	ID    string `json:"id"`
	Label string `json:"label"`
	Root  string `json:"root"`
}
type Item struct {
	Source    string `json:"source"`
	Path      string `json:"path"`
	Name      string `json:"name"`
	Modified  int64  `json:"modified"`
	Size      int64  `json:"size"`
	Type      string `json:"type"`
	Manual    bool   `json:"manual"`
	Reason    string `json:"reason"`
	Completed string `json:"completed"`
	Missing   bool   `json:"missing"`
}
type Index struct {
	Version int      `json:"version"`
	Sources []Source `json:"sources"`
	Items   []Item   `json:"items"`
}
type Disk struct {
	Index Index             `json:"index"`
	Roots map[string]string `json:"roots"`
}
type Selection struct {
	Root    string
	Created time.Time
}
type Store struct {
	mu      sync.Mutex
	path    string
	disk    Disk
	pending map[string]Selection
	open    func(string) error
	pick    func() (string, error)
}
type ScanFile struct {
	Name     string `json:"name"`
	Path     string `json:"webkitRelativePath"`
	Modified int64  `json:"lastModified"`
	Size     int64  `json:"size"`
}

func empty() Index { return Index{Version: 1, Sources: []Source{}, Items: []Item{}} }
func supported(path string) bool {
	switch strings.ToLower(filepath.Ext(path)) {
	case ".doc", ".docx", ".pdf", ".rtf", ".odt":
		return true
	}
	return false
}
func validate(index Index) error {
	if index.Version != 1 || index.Sources == nil || index.Items == nil {
		return errors.New("Непідтримуваний формат індексу")
	}
	sources := map[string]Source{}
	labels := map[string]bool{}
	for _, s := range index.Sources {
		label := strings.ToLower(strings.TrimSpace(s.Label))
		if s.ID == "" || label == "" || sources[s.ID].ID != "" || labels[label] || s.Root == "" {
			return errors.New("Некоректні джерела")
		}
		sources[s.ID] = s
		labels[label] = true
	}
	seen := map[string]bool{}
	for _, item := range index.Items {
		source, exists := sources[item.Source]
		parts := strings.Split(item.Path, "/")
		if !exists || len(parts) < 2 || !strings.EqualFold(parts[0], source.Root) || item.Name != parts[len(parts)-1] || !supported(item.Path) || strings.Contains(item.Path, "\\") || filepath.IsAbs(item.Path) || item.Size < 0 || item.Modified < -62135596800000 || item.Modified > 253402300799999 {
			return errors.New("Некоректні документи")
		}
		for _, p := range parts {
			if p == "" || p == "." || p == ".." {
				return errors.New("Небезпечний шлях документа")
			}
		}
		if item.Type != "rec" && item.Type != "plan" && item.Type != "other" {
			return errors.New("Некоректний тип")
		}
		if item.Completed != "" {
			date, err := time.Parse("2006-01-02", item.Completed)
			if err != nil || date.Year() < 1900 || date.Year() > 2200 {
				return errors.New("Некоректна дата виконання")
			}
		}
		key := item.Source + "\x00" + strings.ToLower(item.Path)
		if seen[key] {
			return errors.New("Повторні записи")
		}
		seen[key] = true
	}
	return nil
}
func atomicSave(path string, disk Disk) error {
	data, err := json.MarshalIndent(disk, "", "  ")
	if err != nil {
		return err
	}
	if old, e := os.ReadFile(path); e == nil {
		if e = os.WriteFile(path+".bak", old, 0600); e != nil {
			return e
		}
	} else if !os.IsNotExist(e) {
		return e
	}
	f, err := os.CreateTemp(filepath.Dir(path), ".oblik-*")
	if err != nil {
		return err
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if _, err = f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}
func (s *Store) update(index Index) error {
	if err := validate(index); err != nil {
		return err
	}
	next := Disk{Index: index, Roots: s.disk.Roots}
	if err := atomicSave(s.path, next); err != nil {
		return err
	}
	s.disk = next
	return nil
}
func (s *Store) scan(root string) ([]ScanFile, error) {
	files := []ScanFile{}
	root, err := filepath.Abs(root)
	if err != nil {
		return nil, err
	}
	root, err = filepath.EvalSymlinks(root)
	if err != nil {
		return nil, err
	}
	err = filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() || entry.Type()&os.ModeSymlink != 0 {
			return nil
		}
		if !supported(path) || strings.HasPrefix(entry.Name(), "~$") {
			return nil
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		if !usableDocumentFile(path, info) {
			return nil
		}
		if len(files) >= 100000 {
			return errors.New("Понад 100000 документів; виберіть меншу папку")
		}
		rel, err := filepath.Rel(filepath.Dir(root), path)
		if err != nil {
			return err
		}
		files = append(files, ScanFile{entry.Name(), filepath.ToSlash(rel), info.ModTime().UnixMilli(), info.Size()})
		return nil
	})
	return files, err
}
func (s *Store) resolve(source, path string) (string, error) {
	root := s.disk.Roots[source]
	if root == "" {
		return "", errors.New("Для цього джерела ще не вибрано папку. Виберіть його у списку «Джерело» та натисніть вибір папки")
	}
	found := false
	for _, item := range s.disk.Index.Items {
		if item.Source == source && item.Path == path && !item.Missing {
			found = true
			break
		}
	}
	if !found {
		return "", errors.New("Документ не зареєстровано або його позначено як відсутній")
	}
	parts := strings.Split(path, "/")
	if len(parts) < 2 || strings.Contains(path, "\\") || !supported(path) {
		return "", errors.New("Некоректний шлях")
	}
	for _, p := range parts {
		if p == "" || p == "." || p == ".." {
			return "", errors.New("Небезпечний шлях")
		}
	}
	root, err := filepath.EvalSymlinks(root)
	if err != nil {
		return "", fmt.Errorf("Папка недоступна: %w", err)
	}
	target, err := filepath.EvalSymlinks(filepath.Join(root, filepath.FromSlash(strings.Join(parts[1:], "/"))))
	if err != nil {
		return "", fmt.Errorf("Файл переміщено, перейменовано або видалено: %w", err)
	}
	rel, err := filepath.Rel(root, target)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return "", errors.New("Файл за межами вибраної папки")
	}
	info, err := os.Stat(target)
	if err != nil {
		return "", err
	}
	if !usableDocumentFile(target, info) || !supported(target) {
		return "", errors.New("Цей файл відкривати не можна")
	}
	return target, nil
}
