package main

import "os"

// Values from the Windows SDK winnt.h. Cloud placeholders are files, not
// directory junctions or symbolic links, even when Go marks them irregular.
func isCloudTag(tag uint32) bool {
	return tag&^uint32(0x0000F000) == 0x9000001A || tag == 0x80000021
}

func usableDocumentFile(path string, info os.FileInfo) bool {
	if info.Mode().IsRegular() {
		return true
	}
	if info.Mode()&os.ModeType != os.ModeIrregular {
		return false
	}
	return platformCloudFile(path)
}
