package main

import (
	"errors"
	"os"
)

func selectFolder() (string, error) {
	if path := os.Getenv("OBLIK_TEST_ROOT"); path != "" {
		return path, nil
	}
	return "", errors.New("Folder dialog is available on Windows")
}
func openDocument(path string) error {
	if log := os.Getenv("OBLIK_TEST_OPEN_LOG"); log != "" {
		return os.WriteFile(log, []byte(path), 0600)
	}
	return errors.New("Windows document opening is not available in this test environment")
}
