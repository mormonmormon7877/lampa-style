package main

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"encoding/xml"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func wordFixture(xmlText string) []byte {
	var b bytes.Buffer
	z := zip.NewWriter(&b)
	f, _ := z.Create("word/document.xml")
	f.Write([]byte(xmlText))
	z.Close()
	return b.Bytes()
}
func syntheticWord() []byte {
	return wordFixture(`<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl><w:tr><w:tc><w:p><w:r><w:t>№</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Дата видачі</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>ПІБ</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Примітка</w:t></w:r></w:p></w:tc></w:tr><w:tr><w:tc><w:p><w:r><w:t>472 СЕДО 2961</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>26.10.2026</w:t></w:r></w:p></w:tc><w:tc><w:p><w:sdt><w:sdtPr><w:rPr><w:caps/></w:rPr></w:sdtPr><w:sdtContent><w:r><w:t>тестенко</w:t></w:r></w:sdtContent></w:sdt><w:r><w:t xml:space="preserve"> Тест Тестович</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Синтетична примітка</w:t></w:r></w:p></w:tc></w:tr></w:tbl><w:tbl><w:tr><w:tc><w:p><w:r><w:t>Дата</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>ПІБ</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Номер СЕДО</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Примітка</w:t></w:r></w:p></w:tc></w:tr><w:tr><w:tc/><w:tc><w:p><w:r><w:t>ПРІЗВИЩЕ ім’я та по батькові</w:t></w:r></w:p></w:tc><w:tc/><w:tc/></w:tr><w:tr><w:tc><w:p><w:r><w:t>31.02.2026</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>ТЕСТОВИЙ Отримувач</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>77</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Невірна дата</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>`)
}
func newStore(t *testing.T) *Store {
	return &Store{path: filepath.Join(t.TempDir(), "register.json"), data: empty()}
}
func TestWordImportFieldsAndInvalidDate(t *testing.T) {
	preview, err := parseDocx(syntheticWord())
	if err != nil {
		t.Fatal(err)
	}
	if len(preview.Records) != 2 || preview.BlankRows != 1 || preview.Tables != 2 {
		t.Fatal("wrong totals", len(preview.Records), preview.BlankRows, preview.Tables)
	}
	r := preview.Records[0]
	if r.Name != "ТЕСТЕНКО Тест Тестович" || r.Date != "2026-10-26" || r.Number != "472" || r.SEDO != "2961" || r.Draft {
		t.Fatalf("field parsing failed: %+v", r)
	}
	draft := preview.Records[1]
	if !draft.Draft || draft.Date != "" || draft.SourceDate != "31.02.2026" {
		t.Fatal("invalid date accepted or discarded")
	}
	if wordDate("29.02.2024") != "2024-02-29" || wordDate("29.02.2026") != "" {
		t.Fatal("calendar validation failed")
	}
}
func TestMixedNumbers(t *testing.T) {
	for _, v := range []struct{ raw, number, sedo string }{{"СЕДО\n3046\n474", "474", "3046"}, {"СЕДО 2982", "", "2982"}, {"472 СЕДО 2961", "472", "2961"}, {"456", "456", ""}} {
		number, sedo := splitNumber(v.raw)
		if number != v.number || sedo != v.sedo {
			t.Fatal("number split failed")
		}
	}
}
func TestRepeatedImportPreservesRecordsAndTrash(t *testing.T) {
	p, _ := parseDocx(syntheticWord())
	s := newStore(t)
	n, _, err := s.importRows(p.Records)
	if err != nil || n != 2 {
		t.Fatal(err, n)
	}
	n, skipped, err := s.importRows(p.Records)
	if err != nil || n != 0 || skipped != 2 {
		t.Fatal("repeat import duplicated data")
	}
	id := s.data.Records[0].ID
	if err = s.trash(id, false); err != nil {
		t.Fatal(err)
	}
	s.importRows(p.Records)
	if len(s.data.Records) != 2 || s.data.Records[0].Deleted == "" {
		t.Fatal("import resurrected deleted row")
	}
	if err = s.trash(id, true); err != nil {
		t.Fatal(err)
	}
	if s.data.Records[0].Deleted != "" {
		t.Fatal("restore failed")
	}
	raw, _ := os.ReadFile(s.path)
	var restored Archive
	json.Unmarshal(raw, &restored)
	if validate(restored) != nil || len(restored.Records) != 2 {
		t.Fatal("saved archive invalid")
	}
	if _, err = os.Stat(s.path + ".bak"); err != nil {
		t.Fatal("backup missing")
	}
}
func TestIdenticalWordRowsKeptOnFirstImport(t *testing.T) {
	raw := syntheticWord()
	z, _ := zip.NewReader(bytes.NewReader(raw), int64(len(raw)))
	f, _ := z.File[0].Open()
	body, _ := io.ReadAll(f)
	f.Close()
	start := strings.Index(string(body), `<w:tr><w:tc><w:p><w:r><w:t>472`)
	end := start + strings.Index(string(body[start:]), `</w:tr>`) + len(`</w:tr>`)
	changed := append(append(append([]byte{}, body[:end]...), body[start:end]...), body[end:]...)
	preview, err := parseDocx(wordFixture(string(changed)))
	if err != nil || len(preview.Records) != 3 {
		t.Fatal(err)
	}
	if preview.Records[0].ImportKey == preview.Records[1].ImportKey {
		t.Fatal("identical source rows collapsed")
	}
	s := newStore(t)
	added, _, err := s.importRows(preview.Records)
	if err != nil || added != 3 {
		t.Fatal(err, added)
	}
	added, skipped, err := s.importRows(preview.Records)
	if err != nil || added != 0 || skipped != 3 {
		t.Fatal("repeat changed identical-row count")
	}
}
func TestValidationAndEditing(t *testing.T) {
	s := newStore(t)
	r, err := s.upsert(Record{Kind: "rec", Date: "2026-11-06", Name: "ТЕСТОВИЙ Отримувач", Number: "1"})
	if err != nil {
		t.Fatal(err)
	}
	r.Note = "updated"
	if _, err = s.upsert(r); err != nil {
		t.Fatal(err)
	}
	if len(s.data.Records) != 1 || s.data.Records[0].Note != "updated" {
		t.Fatal("edit appended instead of updating")
	}
	stale := r
	stale.Note = "stale overwrite"
	if _, err = s.upsert(stale); err == nil {
		t.Fatal("stale edit overwrote a newer revision")
	}
	if s.data.Records[0].Note != "updated" {
		t.Fatal("failed edit changed existing data")
	}

	if _, err = s.upsert(Record{Kind: "rec", Date: "2026-02-31", Name: "Test"}); err == nil {
		t.Fatal("invalid date accepted")
	}
	if _, err = s.upsert(Record{Kind: "plan"}); err == nil {
		t.Fatal("incomplete non-draft accepted")
	}
	if len(s.data.Records) != 1 {
		t.Fatal("failed save changed state")
	}
}
func TestWordExportCanBeParsedAgain(t *testing.T) {
	records := []Record{{Kind: "rec", Date: "2026-11-06", Name: "ТЕСТОВИЙ <&> Отримувач", Number: "17", SEDO: "500", Note: "рядок\nтекст"}, {Kind: "plan", Date: "2026-11-05", Name: "ІНШИЙ Отримувач", SEDO: "600"}}
	raw, err := exportDocx(records)
	if err != nil {
		t.Fatal(err)
	}
	z, err := zip.NewReader(bytes.NewReader(raw), int64(len(raw)))
	if err != nil {
		t.Fatal(err)
	}
	for _, f := range z.File {
		r, _ := f.Open()
		body, _ := io.ReadAll(r)
		r.Close()
		decoder := xml.NewDecoder(bytes.NewReader(body))
		for {
			_, err = decoder.Token()
			if err == io.EOF {
				break
			}
			if err != nil {
				t.Fatal(err)
			}
		}
	}
	preview, err := parseDocx(raw)
	if err != nil || len(preview.Records) != 2 {
		t.Fatal(err, len(preview.Records))
	}
	if preview.Records[0].Name != records[0].Name || preview.Records[0].SEDO != "500" {
		t.Fatal("export lost content")
	}
}
func TestCorruptWordRejected(t *testing.T) {
	for _, raw := range [][]byte{[]byte("not a zip"), wordFixture(`<bad`), wordFixture(`<document/>`)} {
		if _, err := parseDocx(raw); err == nil {
			t.Fatal("corrupt/unsupported document accepted")
		}
	}
}
func TestPrivateDocumentAudit(t *testing.T) {
	path := os.Getenv("REGISTER_PRIVATE_DOCX")
	if path == "" {
		t.Skip("optional private input not provided")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	preview, err := parseDocx(raw)
	if err != nil {
		t.Fatal(err)
	}
	counts := map[string]int{"records": len(preview.Records), "tables": preview.Tables, "blankRows": preview.BlankRows}
	for _, r := range preview.Records {
		counts[r.Kind]++
		if r.Draft {
			counts["drafts"]++
		}
		if r.SEDO != "" {
			counts["sedo"]++
		}
		if r.Name == "" {
			t.Fatal("recipient lost during extraction")
		}
	}
	if counts["records"] != 29 || counts["rec"] != 29 || counts["tables"] != 2 {
		t.Fatal("unexpected private document totals", counts)
	}
	t.Logf("Private document counts only: %+v", counts)
}
