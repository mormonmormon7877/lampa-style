package main

import "errors"

func platformShortcut() (string, error) {
	return "", errors.New("Створення ярлика доступне у Windows")
}
