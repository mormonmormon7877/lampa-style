package main

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"syscall"
	"unsafe"
)

type comObject struct{ vtable *[21]uintptr }

func hresult(code uintptr) error {
	if int32(code) < 0 {
		return fmt.Errorf("Windows COM error 0x%x", uint32(code))
	}
	return nil
}

//go:uintptrescapes
func comCall(object *comObject, index int, args ...uintptr) error {
	values := append([]uintptr{uintptr(unsafe.Pointer(object))}, args...)
	r, _, _ := syscall.SyscallN(object.vtable[index], values...)
	return hresult(r)
}
func platformShortcut() (string, error) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	ole := syscall.NewLazyDLL("ole32.dll")
	status, _, _ := ole.NewProc("OleInitialize").Call(0)
	if err := hresult(status); err != nil {
		return "", err
	}
	defer ole.NewProc("OleUninitialize").Call()
	executable, err := os.Executable()
	if err != nil {
		return "", err
	}
	base, err := os.UserCacheDir()
	if err != nil {
		return "", err
	}
	dir := filepath.Join(base, "ZhurnalDokumentiv")
	if err = os.MkdirAll(dir, 0700); err != nil {
		return "", err
	}
	target := filepath.Join(dir, "Zhurnal_Dokumentiv.exe")
	if !sameRoot(executable, target) {
		source, err := os.Open(executable)
		if err != nil {
			return "", err
		}
		defer source.Close()
		temp, err := os.CreateTemp(dir, "oblik-install-*.exe")
		if err != nil {
			return "", err
		}
		tempName := temp.Name()
		defer os.Remove(tempName)
		if _, err = io.Copy(temp, source); err != nil {
			temp.Close()
			return "", err
		}
		if err = temp.Sync(); err != nil {
			temp.Close()
			return "", err
		}
		if err = temp.Close(); err != nil {
			return "", err
		}
		if err = os.Rename(tempName, target); err != nil {
			return "", fmt.Errorf("Не вдалося оновити програму. Закрийте попередню версію: %w", err)
		}
	}
	iconPath := filepath.Join(dir, "Zhurnal_Dokumentiv.ico")
	if err = os.WriteFile(iconPath, icon, 0600); err != nil {
		return "", err
	}
	desktopID := syscall.GUID{Data1: 0xB4BFCC3A, Data2: 0xDB2C, Data3: 0x424C, Data4: [8]byte{0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41}}
	var desktopPtr *uint16
	shell := syscall.NewLazyDLL("shell32.dll")
	r, _, _ := shell.NewProc("SHGetKnownFolderPath").Call(uintptr(unsafe.Pointer(&desktopID)), 0, 0, uintptr(unsafe.Pointer(&desktopPtr)))
	if err = hresult(r); err != nil {
		return "", err
	}
	defer ole.NewProc("CoTaskMemFree").Call(uintptr(unsafe.Pointer(desktopPtr)))
	// SHGetKnownFolderPath returns a null-terminated Windows path.
	if desktopPtr == nil {
		return "", fmt.Errorf("Windows не повернула шлях робочого столу")
	}
	desktopUnits := make([]uint16, 0, 260)
	terminated := false
	for offset := 0; offset < 32768; offset++ {
		unit := *(*uint16)(unsafe.Add(unsafe.Pointer(desktopPtr), offset*2))
		if unit == 0 {
			terminated = true
			break
		}
		desktopUnits = append(desktopUnits, unit)
	}
	if !terminated {
		return "", fmt.Errorf("Некоректний шлях робочого столу")
	}
	desktop := syscall.UTF16ToString(desktopUnits)
	linkPath := filepath.Join(desktop, "Журнал документів.lnk")
	clsid := syscall.GUID{Data1: 0x00021401, Data4: [8]byte{0xC0, 0, 0, 0, 0, 0, 0, 0x46}}
	iid := syscall.GUID{Data1: 0x000214F9, Data4: [8]byte{0xC0, 0, 0, 0, 0, 0, 0, 0x46}}
	var link *comObject
	r, _, _ = ole.NewProc("CoCreateInstance").Call(uintptr(unsafe.Pointer(&clsid)), 0, 1, uintptr(unsafe.Pointer(&iid)), uintptr(unsafe.Pointer(&link)))
	if err = hresult(r); err != nil {
		return "", err
	}
	defer comCall(link, 2)
	set := func(index int, value string) error {
		p, e := syscall.UTF16PtrFromString(value)
		if e != nil {
			return e
		}
		err := comCall(link, index, uintptr(unsafe.Pointer(p)))
		runtime.KeepAlive(p)
		return err
	}
	if err = set(20, target); err != nil {
		return "", err
	}
	if err = comCall(link, 15, 1); err != nil {
		return "", err
	}
	if err = set(9, dir); err != nil {
		return "", err
	}
	if err = set(7, "Журнал документів"); err != nil {
		return "", err
	}
	iconPtr, _ := syscall.UTF16PtrFromString(iconPath)
	if err = comCall(link, 17, uintptr(unsafe.Pointer(iconPtr)), 0); err != nil {
		return "", err
	}
	persistIID := syscall.GUID{Data1: 0x0000010B, Data4: [8]byte{0xC0, 0, 0, 0, 0, 0, 0, 0x46}}
	var persist *comObject
	if err = comCall(link, 0, uintptr(unsafe.Pointer(&persistIID)), uintptr(unsafe.Pointer(&persist))); err != nil {
		return "", err
	}
	defer comCall(persist, 2)
	pathPtr, _ := syscall.UTF16PtrFromString(linkPath)
	if err = comCall(persist, 6, uintptr(unsafe.Pointer(pathPtr)), 1); err != nil {
		return "", err
	}
	return linkPath, nil
}
