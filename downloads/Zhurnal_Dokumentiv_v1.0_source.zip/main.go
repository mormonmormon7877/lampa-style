package main

import (
	"context"
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync/atomic"
	"time"
)

//go:embed app.html
var page string

//go:embed app.ico
var icon []byte

const address = "127.0.0.1:47833"
const origin = "http://" + address
const version = "1.0"

type Pending struct {
	Records []Record
	Created time.Time
}

var sessionKey string

type App struct {
	store   *Store
	pending map[string]Pending
}

func respond(w http.ResponseWriter, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(value)
}
func fail(w http.ResponseWriter, err error) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(400)
	json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
}
func decode(w http.ResponseWriter, r *http.Request, value any) error {
	return json.NewDecoder(http.MaxBytesReader(w, r.Body, 24<<20)).Decode(value)
}
func (a *App) handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Frame-Options", "DENY")
		if r.Host != address {
			http.Error(w, "Invalid host", 403)
			return
		}
		if r.Method != "GET" && r.Header.Get("Origin") != origin {
			http.Error(w, "Invalid origin", 403)
			return
		}
		switch r.URL.Path {
		case "/":
			if r.URL.Query().Get("key") != sessionKey {
				http.Error(w, "Запустіть програму через EXE або ярлик.", 403)
				return
			}
			if r.Method != "GET" {
				http.Error(w, "Method not allowed", 405)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			fmt.Fprint(w, page)
			return
		case "/app.ico":
			w.Header().Set("Content-Type", "image/x-icon")
			w.Write(icon)
			return
		case "/health":
			w.Header().Set("X-Zhurnal-Version", version)
			return
		}
		if r.URL.Path == "/reopen" && r.Method == "POST" {
			if err := openBrowser(); err != nil {
				fail(w, err)
				return
			}
			respond(w, map[string]bool{"ok": true})
			return
		}
		if sessionKey == "" || r.Header.Get("X-Zhurnal-Key") != sessionKey {
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
			w.WriteHeader(403)
			respond(w, map[string]string{"error": "Вікно застаріло. Запустіть програму через EXE або ярлик."})
			return
		}
		s := a.store
		if r.Method == "GET" {
			s.mu.Lock()
			defer s.mu.Unlock()
			switch r.URL.Path {
			case "/api/state":
				respond(w, s.data)
			case "/api/backup":
				w.Header().Set("Content-Disposition", `attachment; filename="Zhurnal_backup.json"`)
				respond(w, s.data)
			default:
				http.NotFound(w, r)
			}
			return
		}
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		if r.URL.Path == "/api/import/preview" {
			r.Body = http.MaxBytesReader(w, r.Body, 14<<20)
			if err := r.ParseMultipartForm(13 << 20); err != nil {
				fail(w, errors.New("Не вдалося прочитати файл. Максимум 12 МБ"))
				return
			}
			if r.MultipartForm != nil {
				defer r.MultipartForm.RemoveAll()
			}
			file, _, err := r.FormFile("file")
			if err != nil {
				fail(w, errors.New("Виберіть файл DOCX"))
				return
			}
			defer file.Close()
			raw, err := io.ReadAll(io.LimitReader(file, (12<<20)+1))
			if err != nil {
				fail(w, err)
				return
			}
			preview, err := parseDocx(raw)
			if err != nil {
				fail(w, err)
				return
			}
			s.mu.Lock()
			defer s.mu.Unlock()
			known := map[string]bool{}
			for _, record := range s.data.Records {
				known[record.ImportKey] = true
			}
			type Entry struct {
				Record    Record `json:"record"`
				Duplicate bool   `json:"duplicate"`
				Similar   bool   `json:"similar"`
			}
			entries := []Entry{}
			duplicates := 0
			for _, record := range preview.Records {
				duplicate := known[record.ImportKey]
				if duplicate {
					duplicates++
				}
				similar := false
				if !duplicate {
					for _, existing := range s.data.Records {
						if existing.Deleted == "" && existing.Kind == record.Kind && existing.Date == record.Date && existing.Name == record.Name && existing.Number == record.Number && existing.SEDO == record.SEDO {
							similar = true
							break
						}
					}
				}
				entries = append(entries, Entry{record, duplicate, similar})
			}
			for token, pending := range a.pending {
				if time.Since(pending.Created) > 15*time.Minute {
					delete(a.pending, token)
				}
			}
			token := id()
			a.pending[token] = Pending{preview.Records, time.Now()}
			respond(w, map[string]any{"token": token, "entries": entries, "duplicates": duplicates, "warnings": preview.Warnings, "blankRows": preview.BlankRows, "tables": preview.Tables})
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		switch r.URL.Path {
		case "/api/save":
			var record Record
			if err := decode(w, r, &record); err != nil {
				fail(w, err)
				return
			}
			saved, err := s.upsert(record)
			if err != nil {
				fail(w, err)
				return
			}
			respond(w, saved)
		case "/api/trash":
			var v struct {
				ID      string `json:"id"`
				Restore bool   `json:"restore"`
			}
			if err := decode(w, r, &v); err != nil {
				fail(w, err)
				return
			}
			if err := s.trash(v.ID, v.Restore); err != nil {
				fail(w, err)
				return
			}
			respond(w, map[string]bool{"ok": true})
		case "/api/import/commit":
			var v struct {
				Token string   `json:"token"`
				Keys  []string `json:"keys"`
			}
			if err := decode(w, r, &v); err != nil {
				fail(w, err)
				return
			}
			pending, ok := a.pending[v.Token]
			if !ok || time.Since(pending.Created) > 15*time.Minute {
				fail(w, errors.New("Попередній перегляд застарів. Виберіть Word-файл повторно"))
				return
			}
			keys := map[string]bool{}
			for _, key := range v.Keys {
				keys[key] = true
			}
			records := []Record{}
			for _, record := range pending.Records {
				if keys[record.ImportKey] {
					records = append(records, record)
					delete(keys, record.ImportKey)
				}
			}
			if len(keys) > 0 {
				fail(w, errors.New("Пакет імпорту змінено"))
				return
			}
			added, skipped, err := s.importRows(records)
			if err != nil {
				fail(w, err)
				return
			}
			delete(a.pending, v.Token)
			respond(w, map[string]int{"added": added, "skipped": skipped})
		case "/api/restore":
			var archive Archive
			if err := decode(w, r, &archive); err != nil {
				fail(w, err)
				return
			}
			if err := s.save(archive); err != nil {
				fail(w, err)
				return
			}
			respond(w, map[string]bool{"ok": true})
		case "/api/export-word":
			var v struct {
				IDs []string `json:"ids"`
			}
			if err := decode(w, r, &v); err != nil {
				fail(w, err)
				return
			}
			if len(v.IDs) > 10000 {
				fail(w, errors.New("Для експорту виберіть не більше 10000 записів"))
				return
			}
			ids := map[string]bool{}
			for _, item := range v.IDs {
				ids[item] = true
			}
			records := []Record{}
			for _, record := range s.data.Records {
				if ids[record.ID] && record.Deleted == "" {
					records = append(records, record)
				}
			}
			sort.SliceStable(records, func(i, j int) bool { return records[i].Date < records[j].Date })
			raw, err := exportDocx(records)
			if err != nil {
				fail(w, err)
				return
			}
			w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
			w.Header().Set("Content-Disposition", `attachment; filename="Zhurnal.docx"`)
			w.Write(raw)
		case "/api/shortcut":
			path, err := platformShortcut()
			if err != nil {
				fail(w, err)
				return
			}
			respond(w, map[string]string{"path": path})
		default:
			http.NotFound(w, r)
		}
	})
}
func openBrowser() error {
	if runtime.GOOS != "windows" {
		return nil
	}
	for _, path := range []string{filepath.Join(os.Getenv("ProgramFiles"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("ProgramFiles(x86)"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("LOCALAPPDATA"), "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(os.Getenv("ProgramFiles(x86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("ProgramFiles"), "Microsoft", "Edge", "Application", "msedge.exe")} {
		if _, err := os.Stat(path); err == nil {
			return exec.Command(path, "--app="+origin+"/?key="+sessionKey).Start()
		}
	}
	return errors.New("Для відкриття встановіть Chrome або Edge")
}
func report(err error) {
	fmt.Fprintln(os.Stderr, err)
	if runtime.GOOS == "windows" {
		syscallMessage(err.Error())
	}
}
func sameRoot(a, b string) bool {
	if runtime.GOOS == "windows" {
		return strings.EqualFold(filepath.Clean(a), filepath.Clean(b))
	}
	return filepath.Clean(a) == filepath.Clean(b)
}
func main() {
	dir := os.Getenv("ZHURNAL_CONFIG_DIR")
	if dir == "" {
		base, err := os.UserConfigDir()
		if err != nil {
			report(err)
			return
		}
		dir = filepath.Join(base, "ZhurnalDokumentiv")
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		report(err)
		return
	}
	s := &Store{path: filepath.Join(dir, "register.json"), data: empty()}
	if raw, err := os.ReadFile(s.path); err == nil {
		if err = json.Unmarshal(raw, &s.data); err != nil {
			report(fmt.Errorf("Дані пошкоджено; файл не перезаписано. Поруч є попередня копія .bak. %w", err))
			return
		}
		if err = validate(s.data); err != nil {
			report(err)
			return
		}
	} else if !os.IsNotExist(err) {
		report(err)
		return
	}
	sessionKey = id()
	if runtime.GOOS != "windows" && os.Getenv("ZHURNAL_TEST_KEY") != "" {
		sessionKey = os.Getenv("ZHURNAL_TEST_KEY")
	}
	listener, err := net.Listen("tcp4", address)
	if err != nil {
		client := &http.Client{Timeout: 2 * time.Second}
		r, e := client.Get(origin + "/health")
		if e == nil {
			r.Body.Close()
			if r.Header.Get("X-Zhurnal-Version") == version {
				request, _ := http.NewRequest("POST", origin+"/reopen", strings.NewReader("{}"))
				request.Header.Set("Origin", origin)
				response, e := client.Do(request)
				if e != nil {
					report(e)
				} else {
					response.Body.Close()
					if response.StatusCode != 200 {
						report(errors.New("Не вдалося відкрити вікно програми"))
					}
				}
				return
			}
		}
		report(err)
		return
	}
	app := &App{store: s, pending: map[string]Pending{}}
	handler := app.handler()
	server := &http.Server{ReadHeaderTimeout: 5 * time.Second}
	shutdownDone := make(chan struct{})
	var closing atomic.Bool
	shutdown := func() {
		if closing.CompareAndSwap(false, true) {
			go func() {
				ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
				defer cancel()
				server.Shutdown(ctx)
				close(shutdownDone)
			}()
		}
	}
	server.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != address {
			http.Error(w, "Invalid host", 403)
			return
		}
		if r.URL.Path == "/alive" || r.URL.Path == "/quit" {
			if r.Method != "POST" || r.Header.Get("Origin") != origin || r.Header.Get("X-Zhurnal-Key") != sessionKey {
				http.Error(w, "Invalid origin", 403)
				return
			}
			w.WriteHeader(204)
			if r.URL.Path == "/quit" {
				shutdown()
			}
			return
		}
		handler.ServeHTTP(w, r)
	})
	if os.Getenv("ZHURNAL_NO_BROWSER") != "1" {
		if err = openBrowser(); err != nil {
			report(err)
			listener.Close()
			return
		}
	}
	if err = server.Serve(listener); err != nil && err != http.ErrServerClosed {
		report(err)
	}
	if closing.Load() {
		<-shutdownDone
	}
}
