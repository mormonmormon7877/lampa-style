package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type Record struct {
	Revision     int    `json:"revision"`
	ID           string `json:"id"`
	Kind         string `json:"kind"`
	Date         string `json:"date"`
	Name         string `json:"name"`
	Number       string `json:"number"`
	SEDO         string `json:"sedo"`
	Note         string `json:"note"`
	Draft        bool   `json:"draft"`
	Deleted      string `json:"deleted,omitempty"`
	ImportKey    string `json:"importKey,omitempty"`
	SourceNumber string `json:"sourceNumber,omitempty"`
	SourceDate   string `json:"sourceDate,omitempty"`
	Created      string `json:"created"`
	Updated      string `json:"updated"`
}
type Archive struct {
	Version int      `json:"version"`
	Records []Record `json:"records"`
}
type Store struct {
	mu   sync.Mutex
	path string
	data Archive
}

func empty() Archive { return Archive{Version: 1, Records: []Record{}} }
func id() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}
func now() string { return time.Now().Format(time.RFC3339) }
func validDate(s string) bool {
	d, err := time.Parse("2006-01-02", s)
	return err == nil && d.Year() >= 1900 && d.Year() <= 2200
}
func validate(a Archive) error {
	if a.Version != 1 || a.Records == nil {
		return errors.New("Невідомий формат резервної копії")
	}
	if len(a.Records) > 100000 {
		return errors.New("Забагато записів")
	}
	seen := map[string]bool{}
	for _, r := range a.Records {
		if r.ID == "" || seen[r.ID] || (r.Kind != "rec" && r.Kind != "plan") {
			return errors.New("Некоректні або повторні записи")
		}
		seen[r.ID] = true
		if r.Date != "" && !validDate(r.Date) {
			return errors.New("Некоректна дата")
		}
		if !r.Draft && (r.Date == "" || strings.TrimSpace(r.Name) == "") {
			return errors.New("Заповніть дату й отримувача або позначте запис як чернетку")
		}
		if len([]rune(r.Name)) > 512 || len([]rune(r.Note)) > 4000 || len(r.Number) > 256 || len(r.SEDO) > 256 {
			return errors.New("Занадто довгі значення полів")
		}
		for _, stamp := range []string{r.Created, r.Updated, r.Deleted} {
			if stamp != "" {
				if _, err := time.Parse(time.RFC3339, stamp); err != nil {
					return errors.New("Некоректна дата зміни запису")
				}
			}
		}
	}
	return nil
}
func (s *Store) save(a Archive) error {
	if err := validate(a); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(a, "", "  ")
	if err != nil {
		return err
	}
	if old, e := os.ReadFile(s.path); e == nil {
		if e = os.WriteFile(s.path+".bak", old, 0600); e != nil {
			return e
		}
	} else if !os.IsNotExist(e) {
		return e
	}
	f, err := os.CreateTemp(filepath.Dir(s.path), ".register-*")
	if err != nil {
		return err
	}
	temp := f.Name()
	defer os.Remove(temp)
	if _, err = f.Write(raw); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	if err = os.Rename(temp, s.path); err != nil {
		return err
	}
	s.data = a
	return nil
}
func (s *Store) upsert(r Record) (Record, error) {
	r.Name = strings.TrimSpace(r.Name)
	r.Number = strings.TrimSpace(r.Number)
	r.SEDO = strings.TrimSpace(r.SEDO)
	r.Note = strings.TrimSpace(r.Note)
	a := s.data
	a.Records = append([]Record{}, a.Records...)
	r.Updated = now()
	if r.ID == "" {
		r.ID = id()
		r.Created = r.Updated
		r.Deleted = ""
		r.ImportKey = ""
		r.Revision = 1
		a.Records = append(a.Records, r)
	} else {
		found := false
		for i, old := range a.Records {
			if old.ID == r.ID {
				if r.Revision != old.Revision {
					return r, errors.New("Запис уже змінено в іншому вікні. Скасуйте редагування та відкрийте його знову")
				}
				if old.Deleted != "" {
					return r, errors.New("Спочатку відновіть запис із кошика")
				}
				r.Created = old.Created
				r.ImportKey = old.ImportKey
				r.SourceNumber = old.SourceNumber
				r.SourceDate = old.SourceDate
				r.Deleted = ""
				r.Revision = old.Revision + 1
				a.Records[i] = r
				found = true
				break
			}
		}
		if !found {
			return r, errors.New("Запис не знайдено")
		}
	}
	return r, s.save(a)
}
func (s *Store) trash(recordID string, restore bool) error {
	a := s.data
	a.Records = append([]Record{}, a.Records...)
	for i := range a.Records {
		if a.Records[i].ID == recordID {
			a.Records[i].Deleted = now()
			if restore {
				a.Records[i].Deleted = ""
			}
			a.Records[i].Updated = now()
			a.Records[i].Revision++
			return s.save(a)
		}
	}
	return errors.New("Запис не знайдено")
}
func importKey(r Record, occurrence int) string {
	raw, _ := json.Marshal([]string{r.Kind, r.Date, r.Name, r.Number, r.SEDO, r.Note, r.SourceNumber, r.SourceDate})
	h := sha256.Sum256(raw)
	return fmt.Sprintf("%x:%d", h, occurrence)
}
func (s *Store) importRows(records []Record) (int, int, error) {
	a := s.data
	a.Records = append([]Record{}, a.Records...)
	keys := map[string]bool{}
	for _, r := range a.Records {
		if r.ImportKey != "" {
			keys[r.ImportKey] = true
		}
	}
	added, skipped := 0, 0
	for _, r := range records {
		if r.ImportKey == "" {
			return 0, 0, errors.New("Некоректний пакет імпорту")
		}
		if keys[r.ImportKey] {
			skipped++
			continue
		}
		r.ID = id()
		r.Created = now()
		r.Updated = r.Created
		r.Deleted = ""
		r.Revision = 1
		a.Records = append(a.Records, r)
		keys[r.ImportKey] = true
		added++
	}
	if added == 0 {
		return 0, skipped, nil
	}
	if err := s.save(a); err != nil {
		return 0, 0, err
	}
	return added, skipped, nil
}
