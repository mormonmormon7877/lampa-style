package main

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"regexp"
	"strconv"
	"strings"
)

type node struct {
	depth    int
	count    *int
	Name     xml.Name
	Attrs    []xml.Attr
	Children []*node
	Text     string
}

func (n *node) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {
	if n.depth > 256 {
		return errors.New("Занадто складна структура Word-файлу")
	}
	if n.count == nil {
		n.count = new(int)
	}
	*n.count++
	if *n.count > 500000 {
		return errors.New("Занадто багато елементів у Word-файлі")
	}
	n.Name = start.Name
	n.Attrs = start.Attr
	for {
		token, err := d.Token()
		if err != nil {
			return err
		}
		switch t := token.(type) {
		case xml.StartElement:
			child := &node{depth: n.depth + 1, count: n.count}
			if err = child.UnmarshalXML(d, t); err != nil {
				return err
			}
			n.Children = append(n.Children, child)
		case xml.CharData:
			n.Text += string(t)
		case xml.EndElement:
			return nil
		}
	}
}
func (n *node) child(name string) *node {
	for _, c := range n.Children {
		if c.Name.Local == name {
			return c
		}
	}
	return nil
}
func (n *node) attr(name string) string {
	for _, a := range n.Attrs {
		if a.Name.Local == name {
			return a.Value
		}
	}
	return ""
}
func caps(pr *node, fallback bool) bool {
	if pr == nil {
		return fallback
	}
	if n := pr.child("caps"); n != nil {
		return n.attr("val") != "0" && n.attr("val") != "false"
	}
	return fallback
}
func readable(n *node, upper bool) string {
	if n == nil {
		return ""
	}
	if n.Name.Local == "sdt" {
		if p := n.child("sdtPr"); p != nil {
			upper = caps(p.child("rPr"), upper)
		}
		return readable(n.child("sdtContent"), upper)
	}
	if n.Name.Local == "r" {
		upper = caps(n.child("rPr"), upper)
	}
	switch n.Name.Local {
	case "sdtPr", "rPr", "pPr", "tcPr", "instrText":
		return ""
	case "t":
		if upper {
			return strings.ToUpper(n.Text)
		}
		return n.Text
	case "br", "cr":
		return "\n"
	case "tab":
		return " "
	}
	var b strings.Builder
	for _, c := range n.Children {
		b.WriteString(readable(c, upper))
	}
	if n.Name.Local == "p" {
		b.WriteString("\n")
	}
	return b.String()
}
func plain(n *node) string { return strings.TrimSpace(readable(n, false)) }
func cleanName(s string) string {
	s = strings.ReplaceAll(s, "ПРІЗВИЩЕ", "")
	s = strings.ReplaceAll(s, "ім’я та по батькові", "")
	s = strings.ReplaceAll(s, "ім'я та по батькові", "")
	return strings.Join(strings.Fields(s), " ")
}

var datePattern = regexp.MustCompile(`^\s*(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})\s*$`)

func wordDate(raw string) string {
	m := datePattern.FindStringSubmatch(raw)
	if m == nil {
		if validDate(strings.TrimSpace(raw)) {
			return strings.TrimSpace(raw)
		}
		return ""
	}
	day, _ := strconv.Atoi(m[1])
	month, _ := strconv.Atoi(m[2])
	s := fmt.Sprintf("%s-%02d-%02d", m[3], month, day)
	if validDate(s) {
		return s
	}
	return ""
}

var sedoPattern = regexp.MustCompile(`(?i)СЕДО\s*[:№#-]?\s*([\pL\pN][\pL\pN/_.-]*)`)

func splitNumber(raw string) (string, string) {
	flat := strings.Join(strings.Fields(raw), " ")
	match := sedoPattern.FindStringIndex(flat)
	if match == nil {
		return flat, ""
	}
	groups := sedoPattern.FindStringSubmatch(flat)
	number := strings.TrimSpace(flat[:match[0]] + " " + flat[match[1]:])
	return number, groups[1]
}

type ImportPreview struct {
	Records   []Record `json:"records"`
	Warnings  []string `json:"warnings"`
	Tables    int      `json:"tables"`
	BlankRows int      `json:"blankRows"`
}

func parseDocx(raw []byte) (ImportPreview, error) {
	result := ImportPreview{Records: []Record{}, Warnings: []string{}}
	if len(raw) > 12<<20 {
		return result, errors.New("Word-файл більший за 12 МБ")
	}
	z, err := zip.NewReader(bytes.NewReader(raw), int64(len(raw)))
	if err != nil {
		return result, errors.New("Це не коректний файл DOCX")
	}
	var body []byte
	for _, part := range z.File {
		if part.Name == "word/document.xml" {
			if part.UncompressedSize64 > 16<<20 {
				return result, errors.New("Вміст Word-файлу занадто великий")
			}
			r, err := part.Open()
			if err != nil {
				return result, err
			}
			body, err = io.ReadAll(io.LimitReader(r, (16<<20)+1))
			r.Close()
			if err != nil {
				return result, err
			}
			if len(body) > 16<<20 {
				return result, errors.New("Вміст Word-файлу занадто великий")
			}
			break
		}
	}
	if len(body) == 0 {
		return result, errors.New("DOCX не містить основного документа")
	}
	var root node
	if err = xml.Unmarshal(body, &root); err != nil {
		return result, fmt.Errorf("Не вдалося прочитати XML документа: %w", err)
	}
	document := root.child("body")
	if document == nil {
		return result, errors.New("Word-файл не містить таблиць")
	}
	occurrences := map[string]int{}
	for _, table := range document.Children {
		if table.Name.Local != "tbl" {
			continue
		}
		rows := []*node{}
		for _, row := range table.Children {
			if row.Name.Local == "tr" {
				rows = append(rows, row)
			}
		}
		if len(rows) < 1 {
			continue
		}
		cells := func(row *node) []string {
			values := []string{}
			for _, cell := range row.Children {
				if cell.Name.Local == "tc" {
					values = append(values, plain(cell))
				}
			}
			return values
		}
		headers := cells(rows[0])
		kind := ""
		if len(headers) == 4 && strings.Contains(strings.ToLower(headers[0]), "дат") && strings.Contains(strings.ToUpper(headers[2]), "СЕДО") {
			kind = "plan"
		} else if (len(headers) == 4 || len(headers) == 5 && strings.Contains(strings.ToUpper(headers[3]), "СЕДО")) && strings.Contains(strings.ToLower(headers[1]), "дат") {
			kind = "rec"
		}
		if kind == "" {
			result.Warnings = append(result.Warnings, "Непідтримувана таблиця пропущена; очікуються 4 або 5 граф журналу")
			continue
		}
		result.Tables++
		for rowIndex, row := range rows[1:] {
			values := cells(row)
			if len(values) != len(headers) {
				return result, errors.New("У таблиці є об’єднані або пошкоджені комірки; кількість граф має відповідати заголовку")
			}
			r := Record{Kind: kind}
			rawDate := ""
			if kind == "rec" {
				r.SourceNumber = values[0]
				r.Number, r.SEDO = splitNumber(values[0])
				rawDate = values[1]
				r.Name = cleanName(values[2])
				r.Note = values[len(values)-1]
				if len(values) == 5 && strings.TrimSpace(values[3]) != "" {
					r.SEDO = strings.TrimSpace(values[3])
				}
			} else {
				rawDate = values[0]
				r.Name = cleanName(values[1])
				r.SEDO = values[2]
				r.Note = values[3]
			}
			if strings.TrimSpace(r.Number+r.SEDO+rawDate+r.Name+r.Note) == "" {
				result.BlankRows++
				continue
			}
			r.Date = wordDate(rawDate)
			r.SourceDate = rawDate
			r.Draft = r.Date == "" || r.Name == ""
			if r.Draft {
				result.Warnings = append(result.Warnings, fmt.Sprintf("%s, рядок %d: уточніть дату або отримувача; запис буде чернеткою", kind, rowIndex+1))
			}
			base := importKey(r, 0)
			occurrences[base]++
			r.ImportKey = importKey(r, occurrences[base])
			result.Records = append(result.Records, r)
			if len(result.Records) > 100000 {
				return result, errors.New("Забагато записів")
			}
		}
	}
	if result.Tables == 0 {
		return result, errors.New("Не знайдено таблиць журналу у форматі вашого документа")
	}
	return result, nil
}
