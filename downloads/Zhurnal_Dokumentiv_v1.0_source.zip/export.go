package main

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"fmt"
	"strings"
)

func escape(s string) string { var b bytes.Buffer; xml.EscapeText(&b, []byte(s)); return b.String() }
func paragraph(text string, bold bool) string {
	props := `<w:rPr><w:sz w:val="22"/></w:rPr>`
	if bold {
		props = `<w:rPr><w:b/><w:sz w:val="28"/></w:rPr>`
	}
	var result strings.Builder
	result.WriteString("<w:p><w:r>" + props)
	for i, line := range strings.Split(text, "\n") {
		if i > 0 {
			result.WriteString("<w:br/>")
		}
		result.WriteString(`<w:t xml:space="preserve">` + escape(line) + `</w:t>`)
	}
	result.WriteString("</w:r></w:p>")
	return result.String()
}
func exportDocx(records []Record) ([]byte, error) {
	var body strings.Builder
	for ki, kind := range []string{"rec", "plan"} {
		if ki > 0 {
			body.WriteString(`<w:p><w:r><w:br w:type="page"/></w:r></w:p>`)
		}
		title := "ЖУРНАЛ ВИДАЧІ РЕКОМЕНДАЦІЙНИХ ЛИСТІВ"
		headers := []string{"Номер", "Дата видачі", "Кому видано — ПІБ", "Номер СЕДО", "Примітка"}
		if kind == "plan" {
			title = "ЖУРНАЛ ОБЛІКУ ПЛАНІВ ПЕРЕМІЩЕННЯ"
			headers = []string{"Дата", "ПІБ", "Номер СЕДО", "Примітка"}
		}
		body.WriteString(paragraph(title, true))
		widths := []int{1800, 1500, 5000, 2300, 4878}
		if kind == "plan" {
			widths = []int{1700, 6500, 2500, 4778}
		}
		body.WriteString(`<w:tbl><w:tblPr><w:tblW w:w="15478" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>`)
		for _, edge := range []string{"top", "left", "bottom", "right", "insideH", "insideV"} {
			fmt.Fprintf(&body, `<w:%s w:val="single" w:sz="4" w:color="778899"/>`, edge)
		}
		body.WriteString(`</w:tblBorders></w:tblPr><w:tblGrid>`)
		for _, width := range widths {
			fmt.Fprintf(&body, `<w:gridCol w:w="%d"/>`, width)
		}
		body.WriteString(`</w:tblGrid>`)
		row := func(values []string, header bool) {
			body.WriteString(`<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="480" w:hRule="atLeast"/>`)
			if header {
				body.WriteString(`<w:tblHeader/>`)
			}
			body.WriteString(`</w:trPr>`)
			for i, v := range values {
				fmt.Fprintf(&body, `<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/></w:tcPr>`, widths[i])
				body.WriteString(paragraph(v, header))
				body.WriteString(`</w:tc>`)
			}
			body.WriteString(`</w:tr>`)
		}
		row(headers, true)
		count := 0
		for _, r := range records {
			if r.Kind != kind {
				continue
			}
			date := r.Date
			if len(date) == 10 {
				date = date[8:10] + "." + date[5:7] + "." + date[:4]
			}
			note := r.Note
			if r.Draft {
				note = "ЧЕРНЕТКА. " + note
			}
			if kind == "rec" {
				row([]string{r.Number, date, r.Name, r.SEDO, note}, false)
			} else {
				row([]string{date, r.Name, r.SEDO, note}, false)
			}
			count++
		}
		if count == 0 {
			row(make([]string, len(headers)), false)
		}
		body.WriteString(`</w:tbl>`)
	}
	body.WriteString(`<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="680" w:right="680" w:bottom="680" w:left="680"/></w:sectPr>`)
	parts := map[string]string{
		"[Content_Types].xml": `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`,
		"_rels/.rels":         `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`,
		"word/document.xml":   `<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>` + body.String() + `</w:body></w:document>`}
	var buffer bytes.Buffer
	z := zip.NewWriter(&buffer)
	for _, name := range []string{"[Content_Types].xml", "_rels/.rels", "word/document.xml"} {
		f, err := z.Create(name)
		if err != nil {
			return nil, err
		}
		if _, err = f.Write([]byte(parts[name])); err != nil {
			return nil, err
		}
	}
	if err := z.Close(); err != nil {
		return nil, err
	}
	return buffer.Bytes(), nil
}
