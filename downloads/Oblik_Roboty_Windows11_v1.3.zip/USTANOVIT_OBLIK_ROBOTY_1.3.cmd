@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title Oblik roboty 1.3 - install
set "APPDIR=%LOCALAPPDATA%\OblikRoboty"
if not exist "%~dp0Oblik_Roboty.exe" (echo Extract all ZIP files before running this installer. & pause & exit /b 1)
if not exist "%~dp0Oblik_Roboty.ico" (echo Icon file is missing. Extract the entire ZIP. & pause & exit /b 1)
if not exist "%APPDIR%" mkdir "%APPDIR%"
if not exist "%APPDIR%" (echo Cannot create application folder. & pause & exit /b 1)
copy /y "%~dp0Oblik_Roboty.exe" "%APPDIR%\Oblik_Roboty.exe.new" >nul
if errorlevel 1 (echo Cannot copy application. & pause & exit /b 1)
copy /y "%~dp0Oblik_Roboty.ico" "%APPDIR%\Oblik_Roboty_1_3.ico.new" >nul
if errorlevel 1 (echo Cannot copy icon. & pause & exit /b 1)
set "EXE_SHA256=c8a4ced07a6f5dcab898566aea9d6f6fcdcdedb1a647023a2f4ebb4be0ba7933"
set "ICO_SHA256=6df5b1c00af2f68080195d52db7e5447434e28681561e0573f9c5d55140c58de"
set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%BROWSER%" (echo Chrome or Edge not found. & pause & exit /b 1)
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; $exeStage=Join-Path $env:APPDIR 'Oblik_Roboty.exe.new'; $icoStage=Join-Path $env:APPDIR 'Oblik_Roboty_1_3.ico.new'; try { if ((Get-FileHash -LiteralPath $exeStage -Algorithm SHA256).Hash -ne $env:EXE_SHA256) { throw 'EXE checksum mismatch' }; if ((Get-FileHash -LiteralPath $icoStage -Algorithm SHA256).Hash -ne $env:ICO_SHA256) { throw 'ICO checksum mismatch' }; $target=Join-Path $env:APPDIR 'Oblik_Roboty.exe'; $icon=Join-Path $env:APPDIR 'Oblik_Roboty_1_3.ico'; Move-Item -LiteralPath $exeStage -Destination $target -Force; Move-Item -LiteralPath $icoStage -Destination $icon -Force; $sh=New-Object -ComObject WScript.Shell; $desktop=$sh.SpecialFolders('Desktop'); $link=Join-Path $desktop 'Облік роботи.lnk'; $s=$sh.CreateShortcut($link); $oldHtml=Join-Path $env:APPDIR 'Oblik_Roboty.html'; $oldLink=Join-Path $desktop 'Облік роботи (попередня).lnk'; if ((Test-Path -LiteralPath $oldHtml) -and -not (Test-Path -LiteralPath $oldLink)) { $legacy=$sh.CreateShortcut($oldLink); if (([IO.Path]::GetFileName($s.TargetPath) -in @('chrome.exe','msedge.exe')) -and (Test-Path -LiteralPath $s.TargetPath)) { $legacy.TargetPath=$s.TargetPath; $legacy.Arguments=$s.Arguments } else { $legacy.TargetPath=$env:BROWSER; $uri=([Uri]$oldHtml).AbsoluteUri; $legacy.Arguments='--app='+[char]34+$uri+[char]34 }; $legacy.WorkingDirectory=$env:APPDIR; $legacy.IconLocation=$icon+',0'; $legacy.Save() }; $s.TargetPath=$target; $s.Arguments=''; $s.WorkingDirectory=$env:APPDIR; $s.IconLocation=$icon+',0'; $s.Description='Облік роботи 1.3 - відкриття оригіналів'; $s.Save(); $sh.Run([char]34+$link+[char]34,1,$false) | Out-Null } catch { Write-Host ('ERROR: '+($_ | Out-String)); exit 1 } finally { foreach ($stage in @($exeStage,$icoStage)) { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force -ErrorAction SilentlyContinue } } }"
if errorlevel 1 (echo Installation failed. Close the running native application before reinstalling. & pause & exit /b 1)
echo Installed. Use the Oblik roboty desktop shortcut.
pause
endlocal
