package main

import (
	"context"
	"crypto/sha256"
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"time"
)

//go:embed app.html
var page string

const address = "127.0.0.1:47831"
const origin = "http://" + address
const version = "2.0"

func openBrowser() error {
	if runtime.GOOS == "windows" {
		return exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", origin+"/").Start()
	}
	return exec.Command("xdg-open", origin+"/").Start()
}
func report(err error) {
	fmt.Fprintln(os.Stderr, err)
	if runtime.GOOS == "windows" {
		syscallMessage(err.Error())
	}
}
func decode(r *http.Request, v any) error {
	return json.NewDecoder(http.MaxBytesReader(nil, r.Body, 32<<20)).Decode(v)
}
func respond(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(v)
}
func fail(w http.ResponseWriter, err error) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(400)
	json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
}
func (s *Store) routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/state", func(w http.ResponseWriter, r *http.Request) {
		s.mu.Lock()
		defer s.mu.Unlock()
		respond(w, map[string]any{"root": s.root, "archive": s.data, "version": version})
	})
	mux.HandleFunc("/api/folder", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		root, err := selectFolder()
		if err != nil {
			fail(w, err)
			return
		}
		if root == "" {
			respond(w, map[string]bool{"cancelled": true})
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		if err = s.choose(root); err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]string{"root": s.root})
	})
	mux.HandleFunc("/api/scan", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		items, err := s.scan()
		if err != nil {
			fail(w, err)
			return
		}
		respond(w, items)
	})
	mux.HandleFunc("/api/import", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var items []Planned
		if err := decode(r, &items); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		n, err := s.importPlan(items)
		if err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]int{"added": n})
	})
	mux.HandleFunc("/api/person", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var p Person
		if err := decode(r, &p); err != nil {
			fail(w, err)
			return
		}
		p.Name = strings.TrimSpace(p.Name)
		if p.Name == "" {
			fail(w, errors.New("Введіть ПІБ"))
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		for _, old := range s.data.People {
			if normal(old.Name) == normal(p.Name) {
				fail(w, errors.New("Така картка вже існує"))
				return
			}
		}
		a := s.data
		a.People = append(append([]Person{}, a.People...), Person{uid(), p.Name})
		if err := s.save(a); err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]bool{"ok": true})
	})
	mux.HandleFunc("/api/work", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var item Work
		if err := decode(r, &item); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		item.ID = uid()
		item.Date = time.Now().Format(time.RFC3339)
		a := s.data
		a.Work = append(append([]Work{}, a.Work...), item)
		if err := s.save(a); err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]bool{"ok": true})
	})
	mux.HandleFunc("/api/assign", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var item struct {
			ID     string `json:"id"`
			Person string `json:"person"`
		}
		if err := decode(r, &item); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		a := s.data
		a.Documents = append([]Document{}, a.Documents...)
		found := false
		for i := range a.Documents {
			if a.Documents[i].ID == item.ID {
				a.Documents[i].Person = item.Person
				found = true
			}
		}
		if !found {
			fail(w, errors.New("Документ не знайдено"))
			return
		}
		if err := s.save(a); err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]bool{"ok": true})
	})
	mux.HandleFunc("/api/open", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var item struct {
			ID string `json:"id"`
		}
		if err := decode(r, &item); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		for _, d := range s.data.Documents {
			if d.ID == item.ID {
				p, err := s.file(d.Path)
				if err != nil {
					fail(w, fmt.Errorf("Файл не знайдено або переміщено: %w", err))
					return
				}
				if err = openDocument(p); err != nil {
					fail(w, err)
					return
				}
				respond(w, map[string]bool{"ok": true})
				return
			}
		}
		fail(w, errors.New("Документ не знайдено"))
	})
	mux.HandleFunc("/api/backup", func(w http.ResponseWriter, r *http.Request) {
		s.mu.Lock()
		defer s.mu.Unlock()
		w.Header().Set("Content-Disposition", `attachment; filename="Kadrovyi-index-backup.json"`)
		respond(w, s.data)
	})
	mux.HandleFunc("/api/check-legacy", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var files []struct {
			Name   string `json:"name"`
			Size   int64  `json:"size"`
			Digest string `json:"digest"`
		}
		if err := decode(r, &files); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		cache := map[string]string{}
		missing := []string{}
		for _, old := range files {
			found := false
			for _, d := range s.data.Documents {
				if d.Size != old.Size {
					continue
				}
				hash, exists := cache[d.Path]
				if !exists {
					p, err := s.file(d.Path)
					if err != nil {
						continue
					}
					f, err := os.Open(p)
					if err != nil {
						continue
					}
					h := sha256.New()
					_, err = io.Copy(h, f)
					f.Close()
					if err != nil {
						continue
					}
					hash = fmt.Sprintf("%x", h.Sum(nil))
					cache[d.Path] = hash
				}
				if hash == old.Digest {
					found = true
					break
				}
			}
			if !found {
				missing = append(missing, old.Name)
			}
		}
		respond(w, map[string]any{"missing": missing, "checked": len(files)})
	})
	mux.HandleFunc("/api/restore", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var a Archive
		if err := decode(r, &a); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		if err := s.save(a); err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]bool{"ok": true})
	})
	mux.HandleFunc("/api/legacy", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "Method not allowed", 405)
			return
		}
		var old Archive
		if err := decode(r, &old); err != nil {
			fail(w, err)
			return
		}
		if err := validate(old); err != nil {
			fail(w, err)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		a := s.data
		a.People = append([]Person{}, a.People...)
		a.Work = append([]Work{}, a.Work...)
		mapping := map[string]string{}
		for _, p := range old.People {
			for _, existing := range a.People {
				if normal(p.Name) == normal(existing.Name) {
					mapping[p.ID] = existing.ID
					break
				}
			}
			if mapping[p.ID] == "" {
				newID := uid()
				a.People = append(a.People, Person{newID, p.Name})
				mapping[p.ID] = newID
			}
		}
		seen := map[string]bool{}
		for _, item := range a.Work {
			seen[item.ID] = true
		}
		for _, item := range old.Work {
			if !seen[item.ID] {
				item.Person = mapping[item.Person]
				a.Work = append(a.Work, item)
				seen[item.ID] = true
			}
		}
		if err := s.save(a); err != nil {
			fail(w, err)
			return
		}
		respond(w, map[string]bool{"ok": true})
	})
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != address {
			http.Error(w, "Invalid host", 403)
			return
		}
		if r.Method != "GET" && r.Header.Get("Origin") != origin {
			http.Error(w, "Invalid origin", 403)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		if r.URL.Path == "/" {
			if r.Method != "GET" {
				http.Error(w, "Method not allowed", 405)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			fmt.Fprint(w, page)
			return
		}
		mux.ServeHTTP(w, r)
	})
}
func main() {
	dir := os.Getenv("KADROVYI_CONFIG_DIR")
	if dir == "" {
		base, err := os.UserConfigDir()
		if err != nil {
			report(err)
			return
		}
		dir = filepath.Join(base, "KadrovyiArkhiv")
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		report(err)
		return
	}
	s := &Store{config: filepath.Join(dir, "settings-v2.json"), data: emptyArchive()}
	if raw, err := os.ReadFile(s.config); err == nil {
		var config map[string]string
		if json.Unmarshal(raw, &config) == nil && config["root"] != "" {
			if err = s.choose(config["root"]); err != nil {
				report(fmt.Errorf("Cannot reopen archive folder: %w. Select the folder again in the application.", err))
			}
		}
	}
	listener, err := net.Listen("tcp4", address)
	if err != nil {
		client := &http.Client{Timeout: 2 * time.Second}
		r, e := client.Get(origin + "/__health")
		if e == nil {
			r.Body.Close()
			if r.Header.Get("X-Kadrovyi-App") == "browser-v1" {
				if r.Header.Get("X-Kadrovyi-Version") == version {
					if e = openBrowser(); e != nil {
						report(e)
					}
					return
				}
				report(errors.New("Close the old archive tab and restart Windows, then launch version 2.0. Save a backup first."))
				return
			}
		}
		report(err)
		return
	}
	var seen atomic.Int64
	seen.Store(time.Now().Unix())
	handler := s.routes()
	server := &http.Server{ReadHeaderTimeout: 5 * time.Second}
	server.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != address {
			http.Error(w, "Invalid host", 403)
			return
		}
		if r.URL.Path == "/__health" {
			w.Header().Set("X-Kadrovyi-App", "browser-v1")
			w.Header().Set("X-Kadrovyi-Version", version)
			w.Header().Set("Cache-Control", "no-store")
			return
		}
		if r.URL.Path == "/__alive" || r.URL.Path == "/__quit" {
			if r.Method != "POST" || r.Header.Get("Origin") != origin {
				http.Error(w, "Forbidden", 403)
				return
			}
			seen.Store(time.Now().Unix())
			w.WriteHeader(204)
			if r.URL.Path == "/__quit" {
				go server.Shutdown(context.Background())
			}
			return
		}
		seen.Store(time.Now().Unix())
		handler.ServeHTTP(w, r)
	})
	go func() {
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for range ticker.C {
			if time.Now().Unix()-seen.Load() > 600 {
				server.Shutdown(context.Background())
				return
			}
		}
	}()
	if os.Getenv("KADROVYI_NO_BROWSER") != "1" {
		if err = openBrowser(); err != nil {
			report(err)
			listener.Close()
			return
		}
	}
	if err = server.Serve(listener); err != nil && err != http.ErrServerClosed {
		report(err)
	}
}
