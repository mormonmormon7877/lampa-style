package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
	"unicode"
)

const indexName = ".kadrovyi-index-v2.json"

type Person struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}
type Document struct {
	ID       string `json:"id"`
	Person   string `json:"person"`
	Path     string `json:"path"`
	Name     string `json:"name"`
	Size     int64  `json:"size"`
	Modified string `json:"modified"`
}
type Work struct {
	ID     string `json:"id"`
	Person string `json:"person"`
	Kind   string `json:"kind"`
	Date   string `json:"date"`
}
type Archive struct {
	Version   int        `json:"version"`
	People    []Person   `json:"people"`
	Documents []Document `json:"documents"`
	Work      []Work     `json:"work"`
}
type Planned struct {
	Path   string `json:"path"`
	Name   string `json:"name"`
	Person string `json:"person"`
	Size   int64  `json:"size"`
}
type Store struct {
	mu     sync.Mutex
	root   string
	config string
	data   Archive
}

func emptyArchive() Archive {
	return Archive{Version: 2, People: []Person{}, Documents: []Document{}, Work: []Work{}}
}
func uid() string { return fmt.Sprintf("%d", time.Now().UnixNano()) }
func normal(s string) string {
	return strings.ToLower(strings.Join(strings.Fields(strings.ReplaceAll(s, "’", "'")), " "))
}
func documentType(p string) bool {
	switch strings.ToLower(filepath.Ext(p)) {
	case ".pdf", ".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp", ".doc", ".docx", ".xls", ".xlsx", ".txt":
		return true
	}
	return false
}
func (s *Store) file(rel string) (string, error) {
	if s.root == "" {
		return "", errors.New("Спочатку виберіть папку архіву")
	}
	if rel == "" || filepath.IsAbs(rel) || strings.Contains(rel, "\\") {
		return "", errors.New("Некоректний шлях документа")
	}
	clean := filepath.Clean(filepath.FromSlash(rel))
	if clean == "." || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
		return "", errors.New("Шлях за межами архіву")
	}
	p := filepath.Join(s.root, clean)
	resolved, err := filepath.EvalSymlinks(p)
	if err != nil {
		return "", err
	}
	inside, err := filepath.Rel(s.root, resolved)
	if err != nil || inside == ".." || strings.HasPrefix(inside, ".."+string(filepath.Separator)) {
		return "", errors.New("Посилання веде за межі архіву")
	}
	if !documentType(resolved) {
		return "", errors.New("Непідтримуваний тип документа")
	}
	info, err := os.Stat(resolved)
	if err != nil {
		return "", err
	}
	if !info.Mode().IsRegular() {
		return "", errors.New("Це не звичайний файл")
	}
	return resolved, nil
}
func validate(a Archive) error {
	if a.Version != 2 || a.People == nil || a.Documents == nil || a.Work == nil {
		return errors.New("Невідомий формат індексу")
	}
	ids := map[string]bool{}
	for _, p := range a.People {
		if p.ID == "" || strings.TrimSpace(p.Name) == "" || ids[p.ID] {
			return errors.New("Некоректні картки")
		}
		ids[p.ID] = true
	}
	seen := map[string]bool{}
	for _, d := range a.Documents {
		if d.ID == "" || seen[d.ID] || (d.Person != "" && !ids[d.Person]) || d.Path == "" || filepath.IsAbs(d.Path) || strings.Contains(d.Path, "\\") || !documentType(d.Path) {
			return errors.New("Некоректні документи")
		}
		clean := filepath.Clean(filepath.FromSlash(d.Path))
		if clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
			return errors.New("Некоректний шлях")
		}
		seen[d.ID] = true
	}
	for _, w := range a.Work {
		if !ids[w.Person] || strings.TrimSpace(w.Kind) == "" {
			return errors.New("Некоректний журнал")
		}
		if _, err := time.Parse(time.RFC3339, w.Date); err != nil {
			return err
		}
	}
	return nil
}
func atomicJSON(path string, v any, backup bool) error {
	data, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	if backup {
		old, e := os.ReadFile(path)
		if e == nil {
			if e = os.WriteFile(path+".bak", old, 0600); e != nil {
				return e
			}
		} else if !os.IsNotExist(e) {
			return e
		}
	}
	f, err := os.CreateTemp(filepath.Dir(path), ".kadrovyi-tmp-*")
	if err != nil {
		return err
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if _, err = f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}
func (s *Store) choose(root string) error {
	full, err := filepath.Abs(root)
	if err != nil {
		return err
	}
	full, err = filepath.EvalSymlinks(full)
	if err != nil {
		return err
	}
	info, err := os.Stat(full)
	if err != nil {
		return err
	}
	if !info.IsDir() {
		return errors.New("Оберіть папку")
	}
	a := emptyArchive()
	raw, err := os.ReadFile(filepath.Join(full, indexName))
	if err == nil {
		if err = json.Unmarshal(raw, &a); err != nil {
			return fmt.Errorf("Індекс пошкоджено; його не змінено: %w", err)
		}
		if err = validate(a); err != nil {
			return err
		}
	} else if !os.IsNotExist(err) {
		return err
	}
	if err = atomicJSON(s.config, map[string]string{"root": full}, false); err != nil {
		return err
	}
	s.root = full
	s.data = a
	return nil
}
func (s *Store) save(a Archive) error {
	if s.root == "" {
		return errors.New("Папку не вибрано")
	}
	if err := validate(a); err != nil {
		return err
	}
	if err := atomicJSON(filepath.Join(s.root, indexName), a, true); err != nil {
		return err
	}
	s.data = a
	return nil
}
func guessName(rel, root string, people []Person) string {
	parts := strings.Split(filepath.ToSlash(filepath.Dir(rel)), "/")
	parts = append([]string{filepath.Base(root)}, parts...)
	for i := len(parts) - 1; i >= 0; i-- {
		candidate := strings.ReplaceAll(parts[i], "_", " ")
		for _, p := range people {
			if normal(candidate) == normal(p.Name) {
				return p.Name
			}
		}
		words := strings.Fields(candidate)
		if len(words) < 2 || len(words) > 3 {
			continue
		}
		good := true
		for _, w := range words {
			for _, r := range w {
				if !unicode.IsLetter(r) && r != '-' && r != '\'' && r != '’' && r != 'ʼ' {
					good = false
				}
			}
		}
		lower := normal(candidate)
		for _, stop := range []string{"документ", "скан", "архів", "архив", "особов", "личн", "справ", "дело", "рекомендац", "наказ", "приказ", "план"} {
			if strings.Contains(lower, stop) {
				good = false
			}
		}
		if good {
			return strings.Join(words, " ")
		}
	}
	return ""
}
func (s *Store) scan() ([]Planned, error) {
	if s.root == "" {
		return nil, errors.New("Спочатку виберіть папку")
	}
	items := []Planned{}
	err := filepath.WalkDir(s.root, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.Type()&os.ModeSymlink != 0 {
			return nil
		}
		if d.IsDir() {
			return nil
		}
		if !documentType(p) {
			return nil
		}
		rel, err := filepath.Rel(s.root, p)
		if err != nil {
			return err
		}
		info, err := d.Info()
		if err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			return nil
		}
		if len(items) >= 100000 {
			return errors.New("Понад 100000 документів: виберіть меншу папку")
		}
		items = append(items, Planned{Path: filepath.ToSlash(rel), Name: d.Name(), Person: guessName(rel, s.root, s.data.People), Size: info.Size()})
		return nil
	})
	return items, err
}
func (s *Store) importPlan(items []Planned) (int, error) {
	a := s.data
	a.People = append([]Person{}, a.People...)
	a.Documents = append([]Document{}, a.Documents...)
	a.Work = append([]Work{}, a.Work...)
	known := map[string]bool{}
	for _, d := range a.Documents {
		known[normal(d.Path)] = true
	}
	added := 0
	for _, item := range items {
		p, err := s.file(item.Path)
		if err != nil {
			return 0, err
		}
		if known[normal(item.Path)] {
			continue
		}
		info, err := os.Stat(p)
		if err != nil {
			return 0, err
		}
		person := ""
		if name := strings.TrimSpace(item.Person); name != "" {
			for _, old := range a.People {
				if normal(old.Name) == normal(name) {
					person = old.ID
					break
				}
			}
			if person == "" {
				person = uid()
				a.People = append(a.People, Person{person, name})
			}
		}
		a.Documents = append(a.Documents, Document{ID: uid(), Person: person, Path: item.Path, Name: filepath.Base(p), Size: info.Size(), Modified: info.ModTime().Format(time.RFC3339)})
		known[normal(item.Path)] = true
		added++
	}
	if err := s.save(a); err != nil {
		return 0, err
	}
	return added, nil
}
