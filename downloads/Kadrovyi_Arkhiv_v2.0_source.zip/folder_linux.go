package main

import (
	"errors"
	"os/exec"
)

func selectFolder() (string, error) {
	return "", errors.New("Native folder dialog is available on Windows")
}
func openDocument(path string) error { return exec.Command("xdg-open", path).Start() }
