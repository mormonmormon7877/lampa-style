package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fixture(t *testing.T) (*Store, string) {
	t.Helper()
	root := t.TempDir()
	config := filepath.Join(t.TempDir(), "settings.json")
	dir := filepath.Join(root, "Іваненко Іван Іванович", "Скани")
	if e := os.MkdirAll(dir, 0700); e != nil {
		t.Fatal(e)
	}
	p := filepath.Join(dir, "паспорт.pdf")
	if e := os.WriteFile(p, []byte("original bytes"), 0600); e != nil {
		t.Fatal(e)
	}
	s := &Store{config: config, data: emptyArchive()}
	if e := s.choose(root); e != nil {
		t.Fatal(e)
	}
	return s, p
}
func TestReferencesPersistWithoutCopying(t *testing.T) {
	s, p := fixture(t)
	items, e := s.scan()
	if e != nil || len(items) != 1 {
		t.Fatalf("scan: %v %+v", e, items)
	}
	if items[0].Person != "Іваненко Іван Іванович" {
		t.Fatal(items)
	}
	n, e := s.importPlan(items)
	if e != nil || n != 1 {
		t.Fatalf("import: %v %d", e, n)
	}
	n, e = s.importPlan(items)
	if e != nil || n != 0 {
		t.Fatalf("repeat: %v %d", e, n)
	}
	if len(s.data.People) != 1 || len(s.data.Documents) != 1 {
		t.Fatal(s.data)
	}
	data, _ := os.ReadFile(p)
	if string(data) != "original bytes" {
		t.Fatal("original modified")
	}
	raw, _ := os.ReadFile(filepath.Join(s.root, indexName))
	if strings.Contains(string(raw), "original bytes") || strings.Contains(string(raw), "blob") {
		t.Fatal("index contains document content")
	}
	count := 0
	filepath.WalkDir(s.root, func(p string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !d.IsDir() {
			count++
		}
		return nil
	})
	if count != 3 {
		t.Fatalf("expected original, index and index backup only, got %d", count)
	}
	restored := &Store{config: s.config, data: emptyArchive()}
	if e = restored.choose(s.root); e != nil {
		t.Fatal(e)
	}
	if len(restored.data.Documents) != 1 {
		t.Fatal("reload failed")
	}
}
func TestRejectTraversalSymlinkAndBadIndex(t *testing.T) {
	s, p := fixture(t)
	if _, e := s.file("../escape.pdf"); e == nil {
		t.Fatal("traversal accepted")
	}
	outside := filepath.Join(t.TempDir(), "outside.pdf")
	os.WriteFile(outside, []byte("outside"), 0600)
	if e := os.Symlink(outside, filepath.Join(s.root, "link.pdf")); e == nil {
		if _, e = s.file("link.pdf"); e == nil {
			t.Fatal("symlink escape accepted")
		}
	}
	items, e := s.scan()
	if e != nil {
		t.Fatal(e)
	}
	if len(items) != 1 {
		t.Fatal("symlink scanned")
	}
	os.Remove(p)
	if _, e = s.importPlan(items); e == nil {
		t.Fatal("missing original accepted")
	}
	if len(s.data.Documents) != 0 {
		t.Fatal("failed import changed state")
	}
	os.WriteFile(filepath.Join(s.root, indexName), []byte("{bad"), 0600)
	if e = s.choose(s.root); e == nil {
		t.Fatal("corrupt index accepted")
	}
	raw, _ := os.ReadFile(filepath.Join(s.root, indexName))
	if string(raw) != "{bad" {
		t.Fatal("corrupt index overwritten")
	}
}
func TestHTTPOriginAndLegacyVerification(t *testing.T) {
	s, _ := fixture(t)
	items, _ := s.scan()
	s.importPlan(items)
	handler := s.routes()
	call := func(method, url, origin, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, "http://"+address+url, strings.NewReader(body))
		if origin != "" {
			r.Header.Set("Origin", origin)
		}
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, r)
		return w
	}
	if w := call("POST", "/api/person", "http://evil.test", `{"name":"Attack"}`); w.Code != 403 {
		t.Fatal(w.Code)
	}
	sum := sha256.Sum256([]byte("original bytes"))
	body := fmt.Sprintf(`[{"name":"passport.pdf","size":14,"digest":"%x"}]`, sum)
	w := call("POST", "/api/check-legacy", origin, body)
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	var result struct {
		Missing []string `json:"missing"`
	}
	json.Unmarshal(w.Body.Bytes(), &result)
	if len(result.Missing) != 0 {
		t.Fatal(w.Body.String())
	}
	w = call("POST", "/api/check-legacy", origin, `[{"name":"missing.pdf","size":14,"digest":"wrong"}]`)
	json.Unmarshal(w.Body.Bytes(), &result)
	if len(result.Missing) != 1 {
		t.Fatal(w.Body.String())
	}
	before := len(s.data.People)
	w = call("POST", "/api/restore", origin, `{"version":2,"people":[],"documents":[{"id":"bad","path":"../escape.pdf"}],"work":[]}`)
	if w.Code != 400 || len(s.data.People) != before {
		t.Fatal("bad restore changed archive")
	}
}
