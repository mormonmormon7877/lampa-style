package main

func syscallMessage(message string) {}
